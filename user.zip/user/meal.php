<?php
require_once("header.php");
require_once("sidebar.php");
require_once("../admin/database.php");
$user_id=$_SESSION['user_id'];

$query="SELECT * FROM user_meal where user_id='$user_id'";
$recs=db::getRecords($query);

?>


<div class="main-content">
    <div class="row mb-5">
        <div class="col-md-12">
            <div class="card" style="background:#f58220;color: black;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="mb-0 text-light" style="padding-top:7px;">Add Meal Fields</h5>
                        </div>
                        <div class="col-md-3"></div>
                        <div class="col-md-3">
                            <a href="add_meal.php" class="btn btn-primary w-100 text-dark">Add Our Meal</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="card" style="background:transparent;">
            <div class="card-body">
                <table
                    class="table table-bordered table-dashed table-hover digi-dataTable dataTable-resize table-striped"
                    id="componentDataTable3">
                    <thead>
                        <tr>
                            <th><span class="resize-col">ID</span></th>
                            <th><span class="resize-col">Image</span></th>
                            <th><span class="resize-col">Meal</span></th>
                            <th><span class="resize-col">Edit</span></th>
                            <th><span class="resize-col">Action</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
						if($recs)
						{
							foreach($recs as $rec)
							{
								?>

                        <tr>
                            <td><span class="resize-col">1</span></td>
                            <td>
                                <span class="resize-col"><img src="uploads/<?php echo $rec['image']; ?>"
                                        style="width:100px"></span>
                            </td>
                            <td><span class="resize-col"><?php  echo $rec['name'] ?></span></td>
                            <td><span class="resize-col">
                                    <a href="update_meal.php?id=<?php echo $rec['id']; ?>"
                                        class="btn btn-primary w-100 text-dark">Edit</a>
                                </span></td>
                            <td><span class="resize-col">
                                    <a href="action.php?del_meal=<?php  echo $rec['id']; ?>"
                                        class="btn btn-outline-danger w-100 text-dark">Trash</a>
                                </span></td>
                        </tr>
                        <?php
							}
						}
						?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
	require_once("footer.php");
?>