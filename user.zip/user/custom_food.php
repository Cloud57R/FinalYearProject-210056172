<?php
require_once("header.php");
require_once("sidebar.php");
$user_id="";
if(isset($_SESSION['user_id'])){
	$user_id=$_SESSION['user_id'];
}

$query="SELECT DISTINCT (days) AS days
FROM custom_menu2 where user_id='$user_id'
ORDER BY FIELD(days, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
";

$days=db::getRecords($query);




?>

<!-- main content start -->
<div class="main-content">
	<div class="row mb-5">
		<div class="col-md-12">
			<div class="card" style="background:#f58220;color: black;">
				<div class="card-body">
					<div class="row">
						<div class="col-md-6">
							<h5 class="mb-0 text-light" style="padding-top:7px;">Day Meals</h5>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="panel mb-25">
					<div class="panel-body" style="border: 4px solid rgb(193 193 193);
					padding: 40px; padding-left:20px; padding-right:20px; margin-top: 5px;">
					<?php
					if($days){
						foreach($days as $day){
							$d=$day['days'];


                            $query="SELECT DISTINCT (time) AS time
                            FROM custom_menu2 where days='$d' && user_id='$user_id'
                            ORDER BY FIELD(time, 'Breakfast', 'Lunch', 'Dinner')
                            ";

							$timings=db::getRecords($query);
							
								?>
							<div class="row g-3">

							<h1 class="text-center" style="text-decoration:underline"><?php  echo $d;  ?></h1>
							<?php
							if($timings){
								foreach($timings as $timing){
									$t=$timing['time'];
									$query="SELECT * from custom_menu2 where days='$d' && time='$t' && user_id='$user_id'";
									$recs=db::getRecords($query);
								
							?>
							<h3 class="text-center mt-5" style="text-decoration:underline"><?php  echo $t; ?></h3> 
								<?php
									if($recs){
										foreach($recs as $rec){
											$query="SELECT image from foods where id=".$rec['food_id'];
											$image=db::getCell($query);
			 
											$query="SELECT name from foods where id=".$rec['food_id'];
											$food=db::getCell($query);
			 
											$query="SELECT name from user_meal where id=".$rec['meal_id'];
											$meal=db::getCell($query);
											?>
											<div class="col-lg-3 col-6 col-xs-12">
																	<div class="card main_card">
																		<div class="card-body">
																			<img src="../admin/uploads/<?php echo $image ?>" class="w-100" style="height:250px">
																			<h4 class="mt-4 text-dark"><?php echo $food ?></h4>
																			<p class="mt-3 text-dark"><?php echo $meal ?></p>
																			<p class="mt-3 text-dark"><?php  echo $rec['date'] ?></p>
																			<p class="mt-3 text-dark"><?php  echo $rec['quantity'] ?>g</p>
																			<div class="row">
																				<div class="col-md-12">
																					<a href="action.php?del_custom_food=<?php echo $rec['id']; ?>" class="btn btn-outline-danger w-100 text-dark">Trash</a>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
											<?php
										}
									}
                                }
							}
								?>
																


							
							
							</div>
                            <hr>
								<?php
							
						}
					}

					?>
					
				</div>
			</div>
		</div>
	</div>

	<?php
	require_once("footer.php");
?>