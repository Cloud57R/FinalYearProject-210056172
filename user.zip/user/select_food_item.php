<?php
require_once("header.php");
require_once("sidebar.php");



?>


<div class="main-content">
	<div class="row mb-5">
		<div class="col-md-12">
			<div class="card" style="background:#f58220;color: black;">
				<div class="card-body">
					<div class="row">
						<div class="col-md-6">
							<h5 class="mb-0 text-light" style="padding-top:7px;">Add Food Fields</h5>
						</div>
						<div class="col-md-3"></div>
						<div class="col-md-3">
							<a href="add_select_food_item.php" class="btn btn-primary w-100 text-dark">Add Our Food Item</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-12">
		<div class="card" style="background:transparent;">
			<div class="card-body">
				<table class="table table-bordered table-dashed table-hover digi-dataTable dataTable-resize table-striped" id="componentDataTable3">
					<thead>
						<tr>
							<th><span class="resize-col">ID</span></th>
							<th><span class="resize-col">Image</span></th>
							<th><span class="resize-col">Meal</span></th>
							<th><span class="resize-col">Name</span></th>
							<th><span class="resize-col">Quantity</span></th>
							<th><span class="resize-col">Calories</span></th>
							<th><span class="resize-col">Time</span></th>
							<th><span class="resize-col">Edit</span></th>
							<th><span class="resize-col">Action</span></th>
						</tr>
					</thead>
					<tbody>
						
						<tr>
							<td><span class="resize-col">1</span></td>
							<td>
								<span class="resize-col">
									<img style="width:100px" src="images/burger.png">
								</span>
							</td>
							<td><span class="resize-col">Burger</span></td>
							<td><span class="resize-col">Kamran</span></td>
							<td><span class="resize-col">2</span></td>
							<td><span class="resize-col">100 Gram</span></td>

							<td><span class="resize-col">Dinner</span></td>
							<td><span class="resize-col">
								<a href="update_select_food_item.php" class="btn btn-primary w-100 text-dark">Edit</a>
							</span></td>
							<td><span class="resize-col">
								<a href="#" class="btn btn-outline-danger w-100 text-dark">Trash</a>
							</span></td>
						</tr>

						<tr>
							<td><span class="resize-col">2</span></td>
							<td>
								<span class="resize-col">
									<img style="width:100px" src="images/b1.png">
								</span>
							</td>
							<td><span class="resize-col">Noodles</span></td>
							<td><span class="resize-col">Kamran</span></td>
							<td><span class="resize-col">60</span></td>
							<td><span class="resize-col">100 Gram</span></td>

							<td><span class="resize-col">Breakfast</span></td>
							<td><span class="resize-col">
								<a href="update_select_food_item.php" class="btn btn-primary w-100 text-dark">Edit</a>
							</span></td>
							<td><span class="resize-col">
								<a href="#" class="btn btn-outline-danger w-100 text-dark">Trash</a>
							</span></td>
						</tr>

						<tr>
							<td><span class="resize-col">3</span></td>
							<td>
								<span class="resize-col">
									<img style="width:100px" src="images/b2.png">
								</span>
							</td>
							<td><span class="resize-col">Red Velvet Pastry</span></td>
							<td><span class="resize-col">Kamran</span></td>
							<td><span class="resize-col">20</span></td>
							<td><span class="resize-col">100 Gram</span></td>

							<td><span class="resize-col">Lunch</span></td>
							<td><span class="resize-col">
								<a href="update_select_food_item.php" class="btn btn-primary w-100 text-dark">Edit</a>
							</span></td>
							<td><span class="resize-col">
								<a href="#" class="btn btn-outline-danger w-100 text-dark">Trash</a>
							</span></td>
						</tr>

						<tr>
							<td><span class="resize-col">4</span></td>
							<td>
								<span class="resize-col">
									<img style="width:100px" src="images/burger.png">
								</span>
							</td>
							<td><span class="resize-col">Burger</span></td>
							<td><span class="resize-col">Kamran</span></td>
							<td><span class="resize-col">10</span></td>
							<td><span class="resize-col">100 Gram</span></td>

							<td><span class="resize-col">Dinner</span></td>
							<td><span class="resize-col">
								<a href="update_select_food_item.php" class="btn btn-primary w-100 text-dark">Edit</a>
							</span></td>
							<td><span class="resize-col">
								<a href="#" class="btn btn-outline-danger w-100 text-dark">Trash</a>
							</span></td>
						</tr>

						<tr>
							<td><span class="resize-col">5</span></td>
							<td>
								<span class="resize-col">
									<img style="width:100px" src="images/b1.png">
								</span>
							</td>
							<td><span class="resize-col">Noodles</span></td>
							<td><span class="resize-col">Kamran</span></td>
							<td><span class="resize-col">5</span></td>
							<td><span class="resize-col">100 Gram</span></td>

							<td><span class="resize-col">Breakfast</span></td>
							<td><span class="resize-col">
								<a href="update_select_food_item.php" class="btn btn-primary w-100 text-dark">Edit</a>
							</span></td>
							<td><span class="resize-col">
								<a href="#" class="btn btn-outline-danger w-100 text-dark">Trash</a>
							</span></td>
						</tr>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php
require_once("footer.php");
?>