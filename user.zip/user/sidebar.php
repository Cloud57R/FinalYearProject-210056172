<style>
    body{
        font-family:"Jost", sans-serif !important;
    }
</style>

<!-- main sidebar start -->
<div class="main-sidebar">
    <div class="main-menu" style="background:#ffffff">
        <ul class="sidebar-menu scrollable">
            <li class="sidebar-item open">
                <a role="button" class="sidebar-link-group-title has-sub">Dashboard</a>
                <ul class="sidebar-link-group">
                    
                    <li class="sidebar-dropdown-item">
                        <a href="meal.php" class="sidebar-link"><span class="nav-icon"><i class="fa-light fa-user-tie"></i></span> <span class="sidebar-txt">Meal</span></a>
                    </li>

                    

                    <li class="sidebar-dropdown-item">
                        <a href="custom_food.php" class="sidebar-link"><span class="nav-icon"><i class="fa-light fa-user-tie"></i></span> <span class="sidebar-txt"> Custom Food</span></a>
                    </li>

                    <li class="sidebar-dropdown-item">
                        <a href="non_custom_meal.php" class="sidebar-link"><span class="nav-icon"><i class="fa-light fa-user-tie"></i></span> <span class="sidebar-txt"> Non Custom Meal</span></a>
                    </li>

                    <li class="sidebar-dropdown-item">
                        <a href="water_in_take.php" class="sidebar-link"><span class="nav-icon"><i class="fa-light fa-user-tie"></i></span> <span class="sidebar-txt"> Water In-Take</span></a>
                    </li>
                </ul>
            </li>

        </ul>
    </div>
</div>
    <!-- main sidebar end -->