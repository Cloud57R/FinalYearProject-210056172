<?php
require_once("header.php");
require_once("sidebar.php");
$status="";

echo $query="SELECT * FROM user where id='$user_id'";
$userr=db::getRecord($query);

$bmi=($userr['weight']/($userr['height']*$userr['height']))* 703;

if($bmi<=18.5){
    $status="Underweight";
}
if($bmi>18.5 && $bmi<=24.8){
    $status="Normal weight";
}
if($bmi>24.9 && $bmi<=29.9){
    $status="Overweight";
}
if($bmi>30){
    $status="Obesity";
}



?>
<style>
 body{
    font-family:"Jost", sans-serif !important;
}
</style>
<!-- main content start -->
<div class="main-content">
    <div class="DashB1">
        <h2>Dashboard</h2>
        
    </div>
    <div class="row mb-25">
        <div class="col-lg-3 col-6 col-xs-12" style="border: 4px solid #c1c1c1;">
            <div class="dashboard-top-box rounded-bottom panel-bg">
                <div class="left">
                    <h3>5</h3>
                    <a href="#">Total meals</a>
                </div>
                <div class="right">
                    <span class="text-primary">+16.24%</span>
                    <div class="part-icon rounded">
                        <span><i class="fa-light fa-dollar-sign"></i></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-6 col-xs-12" style="border: 4px solid #c1c1c1;">
            <div class="dashboard-top-box rounded-bottom panel-bg">
                <div class="left">
                    <h3><?php echo $bmi; ?></h3>
                    <a href="#">BMI</a>
                </div>
                <div class="right">
                    <span class="text-primary" style="font-size:15px"><?php  echo $status ?></span>
                    <div class="part-icon rounded">
                        <span><i class="fa-light fa-bag-shopping"></i></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="border: 4px solid rgb(193 193 193);
    margin-top: 10px;">
    <div class="col-xxl-12">
        <div class="panel chart-panel-1">
            <div class="panel-header">
                <h5 style="font-family:Jost, sans-serif !important;
                " 
                

</div>

<?php
require_once("footer.php")
?>