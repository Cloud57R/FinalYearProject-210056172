<?php
require_once("header.php");
require_once("sidebar.php");
require_once("../admin/database.php");

$query="SELECT * FROM water_in_take where user_id='$user_id'";
$recs=db::getRecords($query);


$query="SELECT water_in_take FROM user where id='$user_id'";
$daily=db::getCell($query);

?>


<div class="main-content">
    <div class="row mb-5">
        <div class="col-md-12">
            <div class="card" style="background:#f58220;color: black;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="mb-0 text-light" style="padding-top:7px;">Daily Water In-Take (<?php  echo $daily; ?> ml)</h5>
                        </div>
                        <div class="col-md-3"></div>
                        <div class="col-md-3">
                            <a href="add_water_in_take.php" class="btn btn-primary w-100 text-dark">Add Water In-Take</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="card" style="background:transparent;">
            <div class="card-body">
                <table
                    class="table table-bordered table-dashed table-hover digi-dataTable dataTable-resize table-striped"
                    id="componentDataTable3">
                    <thead>
                        <tr>
                            <th><span class="resize-col">ID</span></th>
                            <th><span class="resize-col">Date</span></th>
                            <th><span class="resize-col">Water Value</span></th>
                            <th><span class="resize-col">Edit</span></th>
                            <th><span class="resize-col">Action</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
						if($recs)
						{
                            $i=1;
							foreach($recs as $rec)
							{
								?>

                        <tr>
                            <td><span class="resize-col"><?php   echo $i; ?></span></td>
                            <td><span class="resize-col"><?php  echo $rec['date'] ?></span></td>
                            <td><span class="resize-col"><?php  echo $rec['water_value'] ?>/<?php  echo $daily; ?></span></td>
                            <td><span class="resize-col">
                                    <a href="update_water_in_take.php?id=<?php echo $rec['id']; ?>"
                                        class="btn btn-primary w-100 text-dark">Edit</a>
                                </span></td>
                            <td><span class="resize-col">
                                    <a href="action.php?del_water_in_take=<?php  echo $rec['id']; ?>"
                                        class="btn btn-outline-danger w-100 text-dark">Trash</a>
                                </span></td>
                        </tr>
                        <?php
                        $i++;
							}
						}
						?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
	require_once("footer.php");
?>