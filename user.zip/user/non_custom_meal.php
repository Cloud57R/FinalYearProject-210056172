<?php
require_once("header.php");
require_once("sidebar.php");
$user_id="";
if(isset($_SESSION['user_id'])){
	$user_id=$_SESSION['user_id'];
}

$query="SELECT DISTINCT (day) AS day
FROM custom_menu where user_id='$user_id'
ORDER BY FIELD(day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
";

$days=db::getRecords($query);




?>

<!-- main content start -->
<div class="main-content">
	<div class="row mb-5">
		<div class="col-md-12">
			<div class="card" style="background:#f58220;color: black;">
				<div class="card-body">
					<div class="row">
						<div class="col-md-6">
							<h5 class="mb-0 text-light" style="padding-top:7px;">Day Meals</h5>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="panel mb-25">
					<div class="panel-body" style="border: 4px solid rgb(193 193 193);
					padding: 40px; padding-left:20px; padding-right:20px; margin-top: 5px;">
					<?php
					if($days){
						foreach($days as $day){
							$d=$day['day'];

                            $query="SELECT DISTINCT (time) AS time
                            FROM custom_menu where day='$d' &&  user_id='$user_id'
                            ORDER BY FIELD(time, 'Breakfast', 'Lunch', 'Dinner')
                            ";


							$timings=db::getRecords($query);
							
								?>
							<div class="row g-3">

							<h1 class="text-center" style="text-decoration:underline"><?php  echo $d;  ?></h1>
							<?php
							if($timings){
								foreach($timings as $timing){
									$t=$timing['time'];
									$query="SELECT * from custom_menu where day='$d' && time='$t' && user_id='$user_id'";
									$recs=db::getRecords($query);
									
								
							?>
							<h3 class="text-center mt-5" style="text-decoration:underline"><?php  echo $t; ?></h3> 
								<?php
									if($recs){
										foreach($recs as $rec){
											
			 
											$query="SELECT * from meal where id=".$rec['menu_id'];
											$meal=db::getRecord($query);
											?>
											<div class="col-lg-3 col-6 col-xs-12">
																	<div class="card main_card">
																		<div class="card-body">
																			<img src="../admin/uploads/<?php echo $meal['image'] ?>" class="w-100" style="height:250px">
																			<h4 class="mt-4 text-dark"><?php echo $meal['name'] ?></h4>
																			<p class="mt-3 text-dark"><?php echo $rec['date']; ?></p>
																			<div class="row">
																				<div class="col-md-12">
																					<a href="food_item.php?menu_id=<?php echo $rec['menu_id']; ?>" class="btn btn-outline-primary w-100 text-dark">View Menu</a>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
											<?php
										}
									}
								}
							}
								?>
																


							
							
							</div>

                            <hr>
								<?php
							
						}
					}
					?>
					
				</div>
			</div>
		</div>
	</div>

	<?php
	require_once("footer.php");
?>