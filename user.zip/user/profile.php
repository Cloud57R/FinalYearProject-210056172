<?php
require_once("header.php");
require_once("sidebar.php");
require_once("../admin/database.php");
 
$query="SELECT * FROM user where id=".$user_id;
$user=db::getRecord($query);
?>

<div class="main-content">

    <div class="main-content">
        <div class="DashB1">
            <h2>Update Profile Fields</h2>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel mb-25">
                    <div class="panel-body">
                        <div class="row g-3">
                            <form action="action.php" method="POST" enctype="multipart/form-data">
                                <div class="col-sm-12">
                                    <label for="formFile" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="formFile" name="name"
                                        value="<?php echo $user['name']; ?>">
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label for="formFile" class="form-label">Email</label>
                                    <input type="text" class="form-control" id="formFile" name="email"
                                        value="<?php echo $user['email']; ?>">
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label for="formFile" class="form-label">Password</label>
                                    <input type="text" class="form-control" id="formFile" name="password"
                                        value="<?php echo $user['password'];?>">
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label for="formFile" class="form-label">Age</label>
                                    <input type="text" class="form-control" id="formFile" name="age"
                                        value="<?php echo $user['age'];?>">
                                </div>
                                <div class="col-sm-12">
                                    <label for="formFile" class="form-label">Height</label>
                                    <input type="text" class="form-control" id="formFile" name="height"
                                        value="<?php echo $user['height']; ?>">
                                </div>
                                <div class="col-sm-12">
                                    <label for="formFile" class="form-label">Weight</label>
                                    <input type="text" class="form-control" id="formFile" name="weight"
                                        value="<?php echo $user['weight']; ?>">
                                </div>
                                <div class="col-sm-12">
                                    <label for="formFile" class="form-label">Water Intake</label>
                                    <input type="text" class="form-control" id="formFile" name="water_in_take"
                                        value="<?php echo $user['water_in_take']; ?>">
                                </div>
                                <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                <div class="row mt-3">
                                    <div class="col-md-4 mx-auto">
                                        <button type="submit" name="update_user"
                                            class="btn btn-success w-100">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>

<?php
require_once("footer.php");
?>