<?php
session_start();
$user_id=$_SESSION['user_id'];
require_once("../admin/database.php");
$db = db::open();
$datee = date("d-m-Y");

//add_meal
if (isset($_POST['add_meal'])) {
    $name = $db->real_escape_string($_POST['name']);
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
    $query_insert = "INSERT INTO `user_meal` (`name`,`image`,`user_id`) VALUES ('$name','$final_file','$user_id')";
    db::query($query_insert);
    echo "<script>location='meal.php'</script>";
}
//update_meal
if (isset($_POST['update_meal'])) {
    $name = $db->real_escape_string($_POST['name']);
    $id = $db->real_escape_string($_POST['id']);
    if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE user_meal SET name='$name' WHERE id='$id'";
        db::query($sql);
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE  user_meal SET name='$name' ,`image`='$final_file' WHERE id='$id'";
        db::query($sql);

    
}
echo "<script>location='meal.php'</script>";
}


//update user
if(isset($_POST['update_user'])){
    $id=$_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password =$_POST['password'];
    $weight = $_POST['weight'];
    $height = $_POST['height'];
    $water_in_take = $_POST['water_in_take'];
    $age=$_POST['age'];
    
    $query="UPDATE `user` SET `name`='$name',`email`='$email',`password`='$password',`weight`='$weight',`height`='$height',`water_in_take`='$water_in_take',`age`='$age' where id='$id'";
    $r = db::query($query);
     echo "<script>location='profile.php'</script>";
  
}

//logout
if(isset($_GET['logout'])){
    unset($_SESSION['user_id']);
    unset($_SESSION['useremail']);
    session_destroy(); 
    echo "<script>location='../login.php'</script>";
    exit(); 
}


//del_meal
if (isset($_GET['del_meal'])) {
    $id = $_GET['del_meal'];
    $sql = "DELETE FROM user_meal WHERE id='$id'";
    db::query($sql);
    echo "<script>location='meal.php'</script>";
}

//add_food_item
if (isset($_POST['add_food_item'])) {
    $name = $db->real_escape_string($_POST['name']);
    $meal = $db->real_escape_string($_POST['meal']);
    $time = $db->real_escape_string($_POST['time']);
    $quantity = $db->real_escape_string($_POST['quantity']);
    $calories = $db->real_escape_string($_POST['calories']);


    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
    $query_insert = "INSERT INTO `food_item` ( `name`, `quantity`, `calories`, `image`, `time`, `meal`) VALUES ('$name','$quantity','$calories','$final_file','$time','$meal')";
    db::query($query_insert);
    echo "<script>location='select_food_item.php'</script>";
}


//update_food_item
if (isset($_POST['update_food_item'])) {
    $name = $db->real_escape_string($_POST['name']);
    $meal = $db->real_escape_string($_POST['meal']);
    $time = $db->real_escape_string($_POST['time']);
    $quantity = $db->real_escape_string($_POST['quantity']);
    $calories = $db->real_escape_string($_POST['calories']);


    $id=$db->real_escape_string($_POST['id']);
    if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE  food_item SET name='$name',meal='$meal', time='$time',quantity='$quantity',calories='$calories' WHERE id='$id'";
        db::query($sql);
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE  food_item SET  name='$name',meal='$meal', time='$time',quantity='$quantity',calories='$calories',image=$final_file WHERE id='$id'";
        echo db::query($sql);
        echo "$sql";
        exit ();
    }
    echo "<script>location='select_food_item.php'</script>";
}
//del_food_item
if (isset($_GET['del_food_item'])) {
    $id = $_GET['del_food_item'];
    $sql = "DELETE FROM  food_item WHERE id='$id'";
    db::query($sql);
    echo "<script>location='select_food_item.php'</script>";
}

//del_non_custom_food_item
if (isset($_GET['del_non_custom_food_item'])) {
    $id = $_GET['del_non_custom_food_item'];
    $sql = "DELETE FROM  food_item WHERE id='$id'";
    db::query($sql);
    echo "<script>location='non_custom_meal.php'</script>";
}

//del_custom_food
if (isset($_GET['del_custom_food'])) {
    $id = $_GET['del_custom_food'];
    $sql = "DELETE FROM custom_menu2 WHERE id='$id'";
    db::query($sql);
    echo "<script>location='custom_food.php'</script>";
}

//add_water_in_take
if (isset($_POST['add_water_in_take'])) {
    $date = $db->real_escape_string($_POST['date']);
    $user_id = $db->real_escape_string($_POST['user_id']);
    $water_value = $db->real_escape_string($_POST['water_value']);
    

    $query_insert = "INSERT INTO `water_in_take` (`date`,`water_value`,`user_id`) VALUES ('$date','$water_value','$user_id')";
    db::query($query_insert);
    echo "<script>location='water_in_take.php'</script>";
}
//update_water_in_take
if (isset($_POST['update_water_in_take'])) {
    $date = $db->real_escape_string($_POST['date']);
    $water_value = $db->real_escape_string($_POST['water_value']);
    $id = $db->real_escape_string($_POST['id']);

    $sql = "UPDATE water_in_take SET date='$date',water_value='$water_value' WHERE id='$id'";
    db::query($sql);
    
    echo "<script>location='water_in_take.php'</script>";
}
//del_water_in_take
if (isset($_GET['del_water_in_take'])) {
    $id = $_GET['del_water_in_take'];
    $sql = "DELETE FROM water_in_take WHERE id='$id'";
    db::query($sql);
    echo "<script>location='water_in_take.php'</script>";
}

?>