<?php
require_once("header.php");
require_once("sidebar.php");



?>
<div class="main-content">
    <div class="main-content">
        <div class="DashB1">
            <h2>Update Food Item</h2>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel mb-25">
                    <div class="panel-body" style=" border: 4px solid rgb(193 193 193);
					">
                        <div class="row ">
                            <form action="action.php" method="POST" enctype="multipart/form-data">
                                <div class="col-sm-12">
                                    <label>Meal</label>
                                    <select style="height: 50px !important;" class="form-select" name="meal"
                                        aria-label="Default select example">
                                        <option selected>Select Meal</option>

                                        <option name="name">Burger</option>
                                        <option name="name">Noodles</option>
                                        <option name="name">Red Velvet Pastry</option>

                                    </select>
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label>Name</label>
                                    <input class="form-control" type="text" id="formFile" name="name"
                                        style="height: 50px !important;">
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label>Quantity</label>
                                    <input class="form-control" type="text" id="formFile" name="quantity"
                                        style="height: 50px !important;">
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label>Calories</label>
                                    <input class="form-control" type="text" id="formFile" name="calories"
                                        style="height: 50px !important;">
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label>Timing</label>
                                    <select class="form-select" style="height: 50px !important;"
                                        aria-label="Default select example" name="time">
                                        <option selected value="">Select Timing</option>
                                        <option value="Breakfast">Breakfast</option>
                                        <option value="Dinner">Dinner</option>
                                        <option value="Lunch">Lunch</option>
                                    </select>
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label>Upload Your Image</label>
                                    <input class="form-control" type="file" name="image"
                                        style="height: 50px !important;">
                                </div>
                                <div class="row">
                                    <div class="col-md-4 mx-auto">
                                        <button class="btn btn-success w-100 mt-5" name="" type="submit">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
require_once("footer.php")
?>