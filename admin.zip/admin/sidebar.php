<style>
  body {
    font-family: "Jost", sans-serif !important;
  }
</style>
<!-- main sidebar start -->
<div class="main-sidebar">
  <div class="main-menu" style="background:#ffffff">
    <ul class="sidebar-menu scrollable">
      <li class="sidebar-item open">
        <a role="button" class="sidebar-link-group-title has-sub">Dashboard</a>
        <ul class="sidebar-link-group">
          <li class="sidebar-dropdown-item">
            <a href="logo.php" class="sidebar-link">
              <span class="nav-icon">
                <i class="fa-light fa-cart-shopping-fast"></i>
              </span>
              <span class="sidebar-txt">Logo</span>
            </a>
          </li>
          <li class="sidebar-dropdown-item">
            <a href="banner.php" class="sidebar-link">
              <span class="nav-icon">
                <i class="fa-light fa-user-headset"></i>
              </span>
              <span class="sidebar-txt">Banner</span>
            </a>
          </li>
          <li class="sidebar-dropdown-item">
            <a href="about.php" class="sidebar-link">
              <span class="nav-icon">
                <i class="fa-light fa-user-headset"></i>
              </span>
              <span class="sidebar-txt">About Us</span>
            </a>
          </li>
          <li class="sidebar-dropdown-item">
            <a href="meal.php" class="sidebar-link">
              <span class="nav-icon">
                <i class="fa-light fa-user-tie"></i>
              </span>
              <span class="sidebar-txt">Meal</span>
            </a>
          </li>
          <li class="sidebar-dropdown-item">
            <a href="select_food_item.php" class="sidebar-link">
              <span class="nav-icon">
                <i class="fa-light fa-user-tie"></i>
              </span>
              <span class="sidebar-txt">food item</span>
            </a>
          </li>
          <li class="sidebar-dropdown-item">
            <a href="food.php" class="sidebar-link">
              <span class="nav-icon">
                <i class="fa-light fa-user-tie"></i>
              </span>
              <span class="sidebar-txt">Food </span>
            </a>
          </li>

          
        </ul>
      </li>
    </ul>
  </div>
</div>