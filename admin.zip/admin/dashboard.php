<?php
require_once("header.php");
require_once("sidebar.php");
?>
<style>
 body{
    font-family:"Jost", sans-serif !important;
}
</style>
<!-- main content start -->
<div class="main-content">
    <div class="DashB1">
        <h2>Food Delivery Dashboard</h2>
        


<?php
require_once("footer.php")
?>