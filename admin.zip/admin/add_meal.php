<?php
require_once("header.php");
require_once("sidebar.php");
require_once("database.php");


?>
<div class="main-content">
    <div class="main-content">
        <div class="DashB1">
            <h2>Add Meal</h2>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel mb-25">
                    <div class="panel-body" style=" border: 4px solid rgb(193 193 193);
					">
                        <div class="row ">
                            <form method="post" action="action.php" enctype="multipart/form-data">
                                <div class="col-sm-12">
                                    <label>Name</label>
                                    <input class="form-control" type="text" id="formFile" name="name"
                                        style="height: 50px !important;">
                                </div>
                                <div class="col-sm-12 mt-2">
                                    <label>Upload Your Image</label>
                                    <input class="form-control" type="file" name="image"
                                        style="height: 50px !important;">
                                </div>
                                <div class="col-sm-12">
                                    <label>Timing</label>
                                    <select class="form-select" aria-label="Default select example" name="time">
                                        <option selected value="">Select Timing</option>
                                        <option value="Breakfast">Breakfast</option>
                                        <option value="Dinner">Dinner</option>
                                        <option value="Lunch">Lunch</option>
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 mx-auto">
                                        <button class="btn btn-success w-100 mt-5" name="add_meal"
                                            type="submit">submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
require_once("footer.php")
?>