<?php
require_once("header.php");
require_once("sidebar.php");
require_once("database.php");
$user_id = $_GET['id'];


echo $query = "SELECT * FROM custom_menu WHERE user_id='$user_id'";
$recs = db::getRecords($query);

?>


<div class="main-content">
    <div class="row mb-5">
        <div class="col-md-12">
            <div class="card" style="background:#f58220;color: black;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="mb-0 text-light" style="padding-top:7px;">Non Cutome Meal</h5>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="card" style="background:transparent;">
            <div class="card-body">
                <table class="table table-bordered table-dashed table-hover digi-dataTable dataTable-resize table-striped" id="componentDataTable3">
                    <thead>
                        <tr>
                            <th><span class="resize-col">ID</span></th>
                            <th><span class="resize-col">Days</span></th>
                            <th><span class="resize-col">Meal</span></th>
                            <th><span class="resize-col">Time</span></th>
                            <th><span class="resize-col">Action</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if($recs) {
                            foreach($recs as $rec) {
                                $query="SELECT name from meal where id=".$rec['menu_id'];
                                $name=db::getCell($query);
                                ?>
                                <tr>
                                    <td><span class="resize-col"><?php echo $rec['id'] ?></span></td>
                                    <td><span class="resize-col"><?php  echo $rec['day'] ?></span></td>
                                    <td><span class="resize-col"><?php echo $name ?></span></td>
                                    <td><span class="resize-col"><?php  echo $rec['time'] ?></span></td>

                                    <td><span class="resize-col">
                                        <a href="food_item.php?menu_id=<?php echo $rec['menu_id']; ?>"
                                            class="btn btn-primary w-100 text-dark">View More</a>
                                        </span></td>
                                    </tr>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php
    require_once("footer.php");
    ?>
