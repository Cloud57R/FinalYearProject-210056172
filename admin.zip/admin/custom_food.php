<?php
require_once("header.php");
require_once("sidebar.php");
require_once("database.php");

// Retrieve the user ID from the URL parameter
$user_id = $_GET['id'];

// Query to fetch custom food items associated with the user
$query = "SELECT * FROM custom_menu2 WHERE user_id='$user_id'";
$recs = db::getRecords($query);
?>

<div class="main-content">
    <div class="row mb-5">
        <div class="col-md-12">
            <div class="card" style="background:#f58220;color: black;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="mb-0 text-light" style="padding-top:7px;">Custom Food </h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="card" style="background:transparent;">
            <div class="card-body">
                <table class="table table-bordered table-dashed table-hover digi-dataTable dataTable-resize table-striped" id="componentDataTable3">
                    <thead>
                        <tr>
                            <th><span class="resize-col">ID</span></th>
                            <th><span class="resize-col">Image</span></th>
                            <th><span class="resize-col">Food</span></th>
                            <th><span class="resize-col">Meal</span></th>
                            <!-- <th><span class="resize-col">Action</span></th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if($recs) {
                            foreach($recs as $rec) {
                               // Fetch image, food name, and meal name using their IDs
                               $food_id = $rec['food_id'];
                               $meal_id = $rec['meal_id'];
                               
                               // Query to fetch image
                               $query_image = "SELECT image FROM foods WHERE id=$food_id";
                               $image = db::getCell($query_image);
                               
                               // Query to fetch food name
                               $query_food = "SELECT name FROM foods WHERE id=$food_id";
                               $food_name = db::getCell($query_food);
                               
                               // Query to fetch meal name
                               $query_meal = "SELECT name FROM user_meal WHERE id=$meal_id";
                               $meal_name = db::getCell($query_meal);
                               ?>
                               <tr>
                                <td><span class="resize-col"><?php echo $rec['id'] ?></span></td>
                                <td><span class="resize-col"><img style="width:100px" src="../admin/uploads/<?php echo $image ?>"></span></td>
                                <td><span class="resize-col"><?php echo $food_name ?></span></td>
                                <td><span class="resize-col"><?php echo $meal_name ?></span></td>
                                <!-- <td><span class="resize-col">
                                    <a href="action.php?del_custom_food=<?php echo $rec['id']; ?>" class="btn btn-outline-danger w-100 text-dark">Trash</a>
                                </span></td> -->
                            </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php
require_once("footer.php");
?>
