<?php
session_start();
require_once("database.php");
$db = db::open();
$datee = date("d-m-Y");
// all insertion code start
//login
if (isset($_POST['loginadmin'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $query="SELECT * FROM admin WHERE email='$email' AND password='$password'";
    $rec = db::getRecord($query);
    if ($rec != NULL) {
        $_SESSION['email'] = $_POST['email'];
        header('location:dashboard.php');
    } else {
        header('location:index.php');
    }
}
//update admin
if (isset($_POST['update_admin'])) {
    $name = $_POST['name'];
    $password = $_POST['password'];
    if ($_FILES['doc_file']['name'] == "") {
        $sql2 = "UPDATE admin SET name='$name',password='$password'";
        $r = db::query($sql2);
        echo "<script>location='profile.php?status=1'</script>";
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['doc_file']['name'];
        $file_loc = $_FILES['doc_file']['tmp_name'];
        $file_size = $_FILES['doc_file']['size'];
        $file_type = $_FILES['doc_file']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql2 = "UPDATE admin SET name='$name',password='$password',image='$final_file'";
        $r = db::query($sql2);
        echo "<script>location='profile.php?status=1'</script>";

    }
}

//logout
if (isset($_GET['logout'])) {
    unset($_SESSION['email']);
    echo "<script>location='index.php'</script>";
}



// update_logo
if (isset($_POST['update_logo'])) {
    $dcp = $db->real_escape_string($_POST['dcp']);
    $id = $db->real_escape_string($_POST['id']);

    if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE logo SET dcp='$dcp' WHERE id='$id'";
        db::query($sql);
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE logo SET dcp='$dcp',image='$final_file' WHERE id='$id'";
        db::query($sql);
        echo "$sql";
    }
    echo "<script>location='logo.php'</script>";
}

// update_banner
if (isset($_POST['update_banner'])) {
    $dcp = $db->real_escape_string($_POST['dcp']);
    $heading = $db->real_escape_string($_POST['heading']);
    $id = $db->real_escape_string($_POST['id']);

    if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE banner SET dcp='$dcp',heading='$heading' WHERE id='$id'";
        db::query($sql);
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE banner SET dcp='$dcp',heading='$heading',image='$final_file' WHERE id='$id'";
        db::query($sql);
        echo "$sql";
    }
    echo "<script>location='banner.php'</script>";
}


//add_About
if (isset($_POST['add_about'])) {
    $heading = $db->real_escape_string($_POST['heading']);
    $dcp = $db->real_escape_string($_POST['dcp']);

    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
    $query_insert = "INSERT INTO `about` (`heading`,`image`,`dcp`) VALUES ('$heading','$final_file','$dcp')";
    db::query($query_insert);
    echo "<script>location='about.php'</script>";
}
//update about
if (isset($_POST['update_about'])) {
    $heading = $db->real_escape_string($_POST['heading']);
    $dcp = $db->real_escape_string($_POST['dcp']);

    $id = $db->real_escape_string($_POST['id']);
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
    $sql = "UPDATE  about SET heading='$heading',dcp='$dcp',image='$final_file' WHERE id='$id'";
    db::query($sql);
    echo "<script>location='about.php'</script>";
}
//del_about
if (isset($_GET['del_about'])) {
    $id = $_GET['del_about'];
    $sql = "DELETE FROM about WHERE id='$id'";
    db::query($sql);
    echo "<script>location='about.php'</script>";
}

//add_meal
if (isset($_POST['add_meal'])) {
    $name = $db->real_escape_string($_POST['name']);
    $time = $db->real_escape_string($_POST['time']);
    
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
    $query_insert = "INSERT INTO `meal` (`name`,`image`,`time`) VALUES ('$name','$final_file','$time')";
    db::query($query_insert);
    echo "<script>location='meal.php'</script>";
}
//update_meal
if (isset($_POST['update_meal'])) {
    $name = $db->real_escape_string($_POST['name']);
    $time = $db->real_escape_string($_POST['time']);
    $id = $db->real_escape_string($_POST['id']);

    if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE meal SET name='$name',time='$time' WHERE id='$id'";
        db::query($sql);
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE  meal SET name='$name' ,`image`='$final_file','time'='$time' WHERE id='$id'";
        db::query($sql);
}
    echo "<script>location='meal.php'</script>";
}
//del_meal
if (isset($_GET['del_meal'])) {
    $id = $_GET['del_meal'];
    $sql = "DELETE FROM meal WHERE id='$id'";
    db::query($sql);
    echo "<script>location='meal.php'</script>";
}




    echo "<script>location='testimonails.php'</script>";

//add_food_item
if (isset($_POST['add_food_item'])) {
    $name = $db->real_escape_string($_POST['name']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $meal = $db->real_escape_string($_POST['meal']);
    $quantity = $db->real_escape_string($_POST['quantity']);
    $calories = $db->real_escape_string($_POST['calories']);


    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
    $query_insert = "INSERT INTO `food_item` ( `name`, `quantity`, `calories`, `image`, `meal`,`dcp`) VALUES ('$name','$quantity','$calories','$final_file','$meal','$dcp')";
    db::query($query_insert);
    echo "<script>location='select_food_item.php'</script>";
}


//update_food_item
if (isset($_POST['update_food_item'])) {
    $name = $db->real_escape_string($_POST['name']);
    $meal = $db->real_escape_string($_POST['meal']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $quantity = $db->real_escape_string($_POST['quantity']);
    $calories = $db->real_escape_string($_POST['calories']);


    $id=$db->real_escape_string($_POST['id']);
    if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE  food_item SET name='$name',meal='$meal',quantity='$quantity',calories='$calories',dcp='$dcp' WHERE id='$id'";
        db::query($sql);
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE  food_item SET  name='$name',meal='$meal',quantity='$quantity',calories='$calories',dcp='$dcp' ,image='$final_file' WHERE id='$id'";
        echo db::query($sql);
    }
    echo "<script>location='select_food_item.php'</script>";
}
//del_food_item
if (isset($_GET['del_food_item'])) {
    $id = $_GET['del_food_item'];
    $sql = "DELETE FROM  food_item WHERE id='$id'";
    db::query($sql);
    echo "<script>location='select_food_item.php'</script>";
}





//add_food
if (isset($_POST['add_food'])) {
    $name = $db->real_escape_string($_POST['name']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $quantity = $db->real_escape_string($_POST['quantity']);
    $calories = $db->real_escape_string($_POST['calories']);


    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
    $query_insert = "INSERT INTO `foods` ( `name`, `quantity`, `calories`, `image`,`dcp`) VALUES ('$name','$quantity','$calories','$final_file','$dcp')";
    db::query($query_insert);
    echo "<script>location='food.php'</script>";
}


//update_food
if (isset($_POST['update_food'])) {
    $name = $db->real_escape_string($_POST['name']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $quantity = $db->real_escape_string($_POST['quantity']);
    $calories = $db->real_escape_string($_POST['calories']);


    $id=$db->real_escape_string($_POST['id']);
    if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE  foods SET name='$name',quantity='$quantity',calories='$calories',dcp='$dcp' WHERE id='$id'";
        db::query($sql);
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE  foods SET  name='$name',quantity='$quantity',calories='$calories',dcp='$dcp' ,image='$final_file' WHERE id='$id'";
        echo db::query($sql);
    }
    echo "<script>location='food.php'</script>";
}
//del_food_item
if (isset($_GET['del_food'])) {
    $id = $_GET['del_food_item'];
    $sql = "DELETE FROM  foods WHERE id='$id'";
    db::query($sql);
    echo "<script>location='food.php'</script>";
}

?>