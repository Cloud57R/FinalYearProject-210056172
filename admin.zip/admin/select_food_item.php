<?php
require_once("header.php");
require_once("sidebar.php");
require_once("database.php");

$query="SELECT * FROM food_item";
$recs=db::getRecords($query);
?>


<div class="main-content">
    <div class="row mb-5">
        <div class="col-md-12">
            <div class="card" style="background:#f58220;color: black;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="mb-0 text-light" style="padding-top:7px;">Add Food Fields</h5>
                        </div>
                        <div class="col-md-3"></div>
                        <div class="col-md-3">
                            <a href="add_select_food_item.php" class="btn btn-primary w-100 text-dark">Add Our Food
                                Item</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="card" style="background:transparent;">
            <div class="card-body">
                <table
                    class="table table-bordered table-dashed table-hover digi-dataTable dataTable-resize table-striped"
                    id="componentDataTable3">
                    <thead>
                        <tr>
                            <th><span class="resize-col">ID</span></th>
                            <th><span class="resize-col">Image</span></th>
                            <th><span class="resize-col">Meal</span></th>
                            <th><span class="resize-col">Name</span></th>
                            <th><span class="resize-col">Quantity</span></th>
                            <th><span class="resize-col">Calories</span></th>
                            <th><span class="resize-col">Description</span></th>
                            <th><span class="resize-col">Edit</span></th>
                            <th><span class="resize-col">Action</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
						if($recs)
						{
							foreach($recs as $recs)
							{
								?>
                        <tr>
                            <td><span class="resize-col"><?php echo $recs['id']; ?></span></td>
                            <td>
                                <span class="resize-col">
                                    <img style="width:100px" src="uploads/<?php echo $recs['image']; ?>">
                                </span>
                            </td>
                            <td><span class="resize-col"><?php echo $recs['meal']; ?></span></td>
                            <td><span class="resize-col"><?php echo $recs['name']; ?></span></td>
                            <td><span class="resize-col"><?php echo $recs['quantity'];; ?></span></td>
                            <td><span class="resize-col"><?php echo $recs['calories']; ?></span></td>
                            <td><span class="resize-col"><?php echo $recs['dcp']; ?></span></td>
                            <td><span class="resize-col">
                                    <a href="update_select_food_item.php?id=<?php echo $recs['id']; ?>"
                                        class="btn btn-primary w-100 text-dark">Edit</a>
                                </span></td>
                            <td><span class="resize-col">
                                    <a href="action.php?del_food_item=<?php  echo $recs['id']; ?>"
                                        class="btn btn-outline-danger w-100 text-dark">Trash</a>
                                </span></td>
                        </tr>
                        <?php
							}
						}
						?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
require_once("footer.php");
?>