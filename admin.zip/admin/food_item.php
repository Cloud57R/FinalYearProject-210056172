<?php
require_once("header.php");
require_once("sidebar.php");
require_once("../admin/database.php");
$user_id = $_GET['id'];

$menu_id = $_GET['menu_id'];
$query="SELECT * from food_item where meal=".$menu_id;
$foods=db::getRecords($query);
?>


<div class="main-content">
	<div class="row mb-5">
		<div class="col-md-12">
			<div class="card" style="background:#f58220;color: black;">
				<div class="card-body">
					<div class="row">
						<div class="col-md-6">
							<h5 class="mb-0 text-light" style="padding-top:7px;">Non Custom Meal</h5>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="row">
		<?php
		if($foods) {
			foreach($foods as $rec) {
				
				?>
				<div class="col-md-4">
					<div class="card">
						<div class="card-body">
							<img src="../admin/uploads/<?php echo $rec['image'] ?>" class="w-100">
							<h3 class="mt-3"><?php echo $rec['name'] ?></h3>
							<h5 class="mt-2"> <?php echo $rec['calories'] ?></h5>
							<p><?php echo $rec['dcp'] ?> </p>
							<p><?php echo $rec['quantity'] ?> Gram</p>
							<!-- <a href="action.php?del_non_custom_food_item=<?php echo $rec['id']; ?>" class="btn btn-outline-danger w-100 text-dark">Trash</a> -->
						</div>
					</div>
				</div>
				<?php
			}
		}
		?>
	</div>
</div>
<?php
require_once("footer.php");
?>