<?php
require_once("header.php");
require_once("sidebar.php");
require_once("database.php");

$query="SELECT * FROM meal";
$meals=db::getRecords($query);
?>
<div class="main-content">
    <div class="main-content">
        <div class="DashB1">
            <h2>Add food Fields</h2>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel mb-25">
                    <div class="panel-body" style=" border: 4px solid rgb(193 193 193);
					">
                        <div class="row ">
                            <form method="post" action="action.php" enctype="multipart/form-data">
                                <div class="col-sm-12">
                                    <label>Meal</label>
                                    <select class="form-select" name="meal" aria-label="Default select example">
                                        <option selected>select Meal</option>
                                        <?php
									if($meals)
									{
										foreach($meals as $meal)
										{
											?>
                                        <option name="name" value="<?php echo $meal['id']; ?>">
                                            <?php echo $meal['name']; ?></option>
                                        <?php
										}
									}
									?>
                                    </select>
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label>Name</label>
                                    <input class="form-control" type="text" id="formFile" name="name"
                                        style="height: 50px !important;">
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label>Quantity</label>
                                    <input class="form-control" type="text" id="formFile" name="quantity"
                                        style="height: 50px !important;">
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label>Calories</label>
                                    <input class="form-control" type="text" id="formFile" name="calories"
                                        style="height: 50px !important;">
                                </div>
                                <div class="col-sm-12 mt-3">
                                    <label>Description</label>
                                    <textarea style="height:150px !important;" class="form-control" name="dcp">
								</textarea>
                                </div>

                                <div class="col-sm-12 mt-2">
                                    <label>Upload Your Image</label>
                                    <input class="form-control" type="file" name="image"
                                        style="height: 50px !important;">
                                </div>
                                <div class="row">
                                    <div class="col-md-4 mx-auto">
                                        <button class="btn btn-success w-100 mt-5" name="add_food_item"
                                            type="submit">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
require_once("footer.php")
?>