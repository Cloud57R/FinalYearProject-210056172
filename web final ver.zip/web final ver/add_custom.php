<?php
require_once("header.php");
require_once("admin/database.php");

if(isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Fetch user meals for the logged-in user
    $data = "SELECT * FROM user_meal WHERE user_id='$user_id'";
    $user_meals = db::getRecords($data);

    $id = $_GET['id'];
    $data = "SELECT * FROM foods WHERE id='$id'";
    $rec = db::getRecord($data);
?>
<section class="lg:flex items-center hidden bg-default-400/10 h-14">
   
</section>

<section class="lg:py-16 py-6">
    <div class="container">
        <div class="grid lg:grid-cols-1 gap-10">
            <div class="lg:col-span-3">
                <form method="post" action="action.php">
                    <div class="grid lg:grid-cols-2 gap-6">
                        <div class="lg:col-span-2">
                            <label class="block text-base/normal text-default-950 mb-2" for="e_mail">Days</label>
                            <select class="block w-full rounded-full py-2.5 px-4 bg-transparent dark:bg-default-50 border border-default-200 focus:ring-transparent focus:border-default-200" aria-label="Default select example" name="days">
                                <option selected value="Monday">Monday</option>
                                <option value="Tuesday">Tuesday</option>
                                <option value="Wednesday">Wednesday</option>
                                <option value="Thursday">Thursday</option>
                                <option value="Friday">Friday</option>
                                <option value="Saturday">Saturday</option>
                                <option value="Sunday">Sunday</option>
                            </select>
                        </div>
                        
                        <input type="hidden" name="food_id" class="form-control" value="<?php echo $rec['id']; ?>">
                        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">

                        <div class="lg:col-span-2">
                            <label class="block text-base/normal text-default-950 mb-2" for="e_mail">Time</label>
                            <select  class="block w-full rounded-full py-2.5 px-4 bg-transparent dark:bg-default-50 border border-default-200 focus:ring-transparent focus:border-default-200" aria-label="Default select example" name="time">
                                <option selected value="Breakfast">Breakfast</option>
                                <option value="Lunch">Lunch</option>
                                <option value="Dinner">Dinner</option>
                            </select>
                        </div>

                        <div class="lg:col-span-2">
                            <label class="block text-base/normal text-default-950 mb-2" for="e_mail">Meal</label>
                            <select  class="block w-full rounded-full py-2.5 px-4 bg-transparent dark:bg-default-50 border border-default-200 focus:ring-transparent focus:border-default-200" aria-label="Default select example" name="meal_id">
                                <?php
                                if($user_meals) {
                                    foreach($user_meals as $user_meal) {
                                        ?>
                                        <option value="<?php echo $user_meal['id']; ?>"><?php echo $user_meal['name']; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <input type="date" name="date" class="form-control">
                        
                        <input type="text" name="quantity" class="form-control" placeholder="Add Quantity">
                        <div>
                            <div>
                                <button type="submit" name="add_custom_food" class="inline-flex items-center justify-center px-10 py-3 rounded-full text-base font-medium bg-primary text-white capitalize transition-all hover:bg-primary-500">add Custom Food</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div><!-- end grid -->
    </div><!-- end container -->
</section>

<?php
} else {
    // If user is not logged in, you can handle it accordingly
    echo "Please log in to view this content.";
}

require_once("footer.php");
?>
