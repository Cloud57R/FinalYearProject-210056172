<?php
require_once("header.php");
require_once("admin/database.php");
$id=$_GET['id'];

$query="SELECT * FROM food_item WHERE meal='$id'";
$items=db::getRecords($query);



?>

<!-- Topbar Search Modal (Small Screen) -->
<div id="mobileSearchSidebar"
    class="hs-overlay hidden w-full h-full fixed top-0 left-0 z-60 overflow-x-hidden overflow-y-auto">
    <div
        class="hs-overlay-open:mt-7 hs-overlay-open:opacity-100 hs-overlay-open:duration-500 mt-0 opacity-0 ease-out transition-all sm:max-w-lg sm:w-full m-3 sm:mx-auto">
        <div class="flex flex-col bg-white shadow-sm rounded-lg">
            <div class="relative flex w-full">
                <span class="absolute start-4 top-3">
                    <i class="w-4 h-4 text-primary-500" data-lucide="search"></i>
                </span>
                <input
                    class="px-10 py-2.5 block w-full border-transparent placeholder-primary-500 rounded-lg text-sm bg-transparent text-primary-500"
                    placeholder="Search for items..." type="search">
                <button class="absolute end-4 top-3" data-hs-overlay="#mobileSearchSidebar">
                    <i class="w-4 h-4 text-primary-500" data-lucide="x"></i>
                </button>
            </div>
        </div>
    </div>
</div>
<section class="lg:flex items-center hidden bg-default-400/10 h-14">
    <div class="container">
        <div class="flex items-center">
            <ol aria-label="Label123" class="flex items-center whitespace-nowrap min-w-0 gap-2">
                <li class="text-sm">
                    <a class="flex items-center gap-2 align-middle text-default-800 transition-all leading-none hover:text-primary-500"
                        href="javascript:void(0)">
                        <i class="w-4 h-4" data-lucide="home"></i> Home <i class="w-4 h-4"
                            data-lucide="chevron-right"></i>
                    </a>
                </li>
                <li aria-current="page"
                    class="text-sm font-medium text-primary truncate leading-none hover:text-primary-500"> Menu </li>
            </ol>
        </div>
    </div>
</section>
<section class="lg:py-8 py-6">
    <div class="container">
        <div class="">


            <div class="">
               
<div class="grid xl:grid-cols-3 sm:grid-cols-2 gap-5">
<?php
                if($items){
                    foreach($items as $item){
                        $query="SELECT * FROM  meal WHERE id='$id'";
                        $foods=db::getRecord($query);
                        
                        ?>
                    <div
                        class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300">

                        <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">
                            <div class="mb-4 mx-auto">
                                <img class="w-full h-full group-hover:scale-105 transition-all"
                                    src="admin/uploads/<?php echo $item['image']; ?>">
                            </div>

                            <div class="pt-2">
                                <div class="flex items-center justify-between mb-4">
                                    <a class="text-default-800 text-xl font-semibold line-clamp-1 after:absolute after:inset-0"
                                        href="#"><?php echo $item['name']; ?></a>
                                    <span class="inline-flex items-center gap-2 mb-4">
                                        <span class="bg-primary rounded-full p-1"><i
                                                class="h-3 w-3 text-white fill-white" data-lucide="star"></i></span>
                                        <span
                                            class="text-sm text-default-950 from-inherit"><?php  echo $item['calories'] ?>Gram</span>
                                    </span>
                                </div>

                                <p class="text-default-500 font-medium mb-3"><?php  echo $item['dcp'] ?></p>


                            </div>
                        </div>

                    </div><!-- end grid-cols -->
                    <?php
                    }
                }
                ?>
                </div><!-- end grid -->
                      
                
            </div>
        </div>
    </div>
</section>

<?php
    require_once("footer.php")
?>