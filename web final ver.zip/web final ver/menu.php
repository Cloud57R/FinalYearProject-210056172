<?php
    require_once("header.php")
?>

<!-- Topbar Search Modal (Small Screen) -->
<div id="mobileSearchSidebar" class="hs-overlay hidden w-full h-full fixed top-0 left-0 z-60 overflow-x-hidden overflow-y-auto">
  <div class="hs-overlay-open:mt-7 hs-overlay-open:opacity-100 hs-overlay-open:duration-500 mt-0 opacity-0 ease-out transition-all sm:max-w-lg sm:w-full m-3 sm:mx-auto">
    <div class="flex flex-col bg-white shadow-sm rounded-lg">
      <div class="relative flex w-full">
        <span class="absolute start-4 top-3">
          <i class="w-4 h-4 text-primary-500" data-lucide="search"></i>
        </span>
        <input class="px-10 py-2.5 block w-full border-transparent placeholder-primary-500 rounded-lg text-sm bg-transparent text-primary-500" placeholder="Search for items..." type="search">
        <button class="absolute end-4 top-3" data-hs-overlay="#mobileSearchSidebar">
          <i class="w-4 h-4 text-primary-500" data-lucide="x"></i>
        </button>
      </div>
    </div>
  </div>
</div>
<section class="lg:flex items-center hidden bg-default-400/10 h-14">
  <div class="container">
    <div class="flex items-center">
      <ol aria-label="Label123" class="flex items-center whitespace-nowrap min-w-0 gap-2">
        <li class="text-sm">
          <a class="flex items-center gap-2 align-middle text-default-800 transition-all leading-none hover:text-primary-500" href="javascript:void(0)">
            <i class="w-4 h-4" data-lucide="home"></i> Home <i class="w-4 h-4" data-lucide="chevron-right"></i>
          </a>
        </li>
        <li aria-current="page" class="text-sm font-medium text-primary truncate leading-none hover:text-primary-500"> Menu </li>
      </ol>
    </div>
  </div>
</section>
<section class="lg:py-8 py-6">
        <div class="container">
            <div class="">
                

                <div class="">

                    <div class="grid xl:grid-cols-3 sm:grid-cols-2 gap-5">
                        <div class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300">
                            <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">
                                <div class="mb-4 mx-auto">
                                    <img class="w-full h-full group-hover:scale-105 transition-all" src="assets/burger-dee4db61.png">
                                </div>

                                <div class="pt-2">
                                    <div class="flex items-center justify-between mb-4">
                                        <a class="text-default-800 text-xl font-semibold line-clamp-1 after:absolute after:inset-0" href="#">Veg Burger</a>
                                        <span class="inline-flex items-center gap-2 mb-4">
                                        <span class="bg-primary rounded-full p-1"><i class="h-3 w-3 text-white fill-white" data-lucide="star"></i></span>
                                        <span class="text-sm text-default-950 from-inherit">100 Gram</span>
                                    </span>
                                    </div>

                                    <p class="text-default-500 font-medium mb-3">It’s the perfect dining experience where every dish is crafted with fresh, high-quality ingredients and served by friendly staff who go.</p>

                                    
                                    <a onclick="document.getElementById('id01').style.display='block'" class="relative z-10 w-full inline-flex items-center justify-center rounded-full border border-primary bg-primary px-6 py-3 text-center text-sm font-medium text-white shadow-sm transition-all duration-500 hover:bg-primary-500" href="#">
                                       
                                    </a><!-- end btn -->
                                </div>
                            </div>
                        </div><!-- end grid-cols -->
                  

                        <div class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300">
                            <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">
                                <div class="mb-4 mx-auto">
                                    <img class="w-full h-full group-hover:scale-105 transition-all" src="assets/noodles-65d947ec.png">
                                </div>

                                <div class="pt-2">
                                    <div class="flex items-center justify-between mb-4">
                                        <a class="text-default-800 text-xl font-semibold line-clamp-1 after:absolute after:inset-0" href="#">Noodles</a>
                                        <span class="inline-flex items-center gap-2 mb-4">
                                        <span class="bg-primary rounded-full p-1"><i class="h-3 w-3 text-white fill-white" data-lucide="star"></i></span>
                                        <span class="text-sm text-default-950 from-inherit">100 Gram</span>
                                    </span>
                                    </div>

                                    <p class="text-default-500 font-medium mb-3">It’s the perfect dining experience where every dish is crafted with fresh, high-quality ingredients and served by friendly staff who go.</p>
                                    
                                   

                                    <a onclick="document.getElementById('id01').style.display='block'" class="relative z-10 w-full inline-flex items-center justify-center rounded-full border border-primary bg-primary px-6 py-3 text-center text-sm font-medium text-white shadow-sm transition-all duration-500 hover:bg-primary-500" href="#">
                                        Order Now
                                    </a>
                                </div>
                            </div>
                        </div><!-- end grid-cols -->

                        <div class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300">
                            <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">
                                <div class="mb-4 mx-auto">
                                    <img class="w-full h-full group-hover:scale-105 transition-all" src="assets/red-velvet-pastry-b09214ba.png">
                                </div>

                                <div class="pt-2">
                                    <div class="flex items-center justify-between mb-4">
                                        <a class="text-default-800 text-xl font-semibold line-clamp-1 after:absolute after:inset-0" href="#">Red
                                            Velvet Pastry</a>
                                        <span class="inline-flex items-center gap-2 mb-4">
                                        <span class="bg-primary rounded-full p-1"><i class="h-3 w-3 text-white fill-white" data-lucide="star"></i></span>
                                        <span class="text-sm text-default-950 from-inherit">100 Gram</span>
                                    </span>
                                    </div>

                                    <p class="text-default-500 font-medium mb-3">It’s the perfect dining experience where every dish is crafted with fresh, high-quality ingredients and served by friendly staff who go.</p>
                                    
                                   

                                    <a onclick="document.getElementById('id01').style.display='block'" class="relative z-10 w-full inline-flex items-center justify-center rounded-full border border-primary bg-primary px-6 py-3 text-center text-sm font-medium text-white shadow-sm transition-all duration-500 hover:bg-primary-500" href="#">
                                        Order Now
                                    </a>
                                </div>
                            </div>
                        </div><!-- end grid-cols -->

                        <div class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300">
                            <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">
                                <div class="mb-4 mx-auto">
                                    <img class="w-full h-full group-hover:scale-105 transition-all" src="assets/spaghetti-c5ad136f.png">
                                </div>

                                <div class="pt-2">
                                    <div class="flex items-center justify-between mb-4">
                                        <a class="text-default-800 text-xl font-semibold line-clamp-1 after:absolute after:inset-0" href="#">Spaghetti</a>
                                        <span class="inline-flex items-center gap-2 mb-4">
                                        <span class="bg-primary rounded-full p-1"><i class="h-3 w-3 text-white fill-white" data-lucide="star"></i></span>
                                        <span class="text-sm text-default-950 from-inherit">100 Gram</span>
                                    </span>
                                    </div>

                                    <p class="text-default-500 font-medium mb-3">It’s the perfect dining experience where every dish is crafted with fresh, high-quality ingredients and served by friendly staff who go.</p>
                                    
                                   

                                    <a onclick="document.getElementById('id01').style.display='block'" class="relative z-10 w-full inline-flex items-center justify-center rounded-full border border-primary bg-primary px-6 py-3 text-center text-sm font-medium text-white shadow-sm transition-all duration-500 hover:bg-primary-500" href="#">
                                        Order Now
                                    </a>
                                </div>
                            </div>
                        </div><!-- end grid-cols -->

                        <div class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300">
                            <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">
                                <div class="mb-4 mx-auto">
                                    <img class="w-full h-full group-hover:scale-105 transition-all" src="assets/hot-chocolate-b95843f9.png">
                                </div>

                                <div class="pt-2">
                                    <div class="flex items-center justify-between mb-4">
                                        <a class="text-default-800 text-xl font-semibold line-clamp-1 after:absolute after:inset-0" href="#">Hot
                                            Chocolate</a>
                                        <span class="inline-flex items-center gap-2 mb-4">
                                        <span class="bg-primary rounded-full p-1"><i class="h-3 w-3 text-white fill-white" data-lucide="star"></i></span>
                                        <span class="text-sm text-default-950 from-inherit">100 Gram</span>
                                    </span>
                                    </div>

                                    <p class="text-default-500 font-medium mb-3">It’s the perfect dining experience where every dish is crafted with fresh, high-quality ingredients and served by friendly staff who go.</p>
                                    
                                   

                                    <a onclick="document.getElementById('id01').style.display='block'" class="relative z-10 w-full inline-flex items-center justify-center rounded-full border border-primary bg-primary px-6 py-3 text-center text-sm font-medium text-white shadow-sm transition-all duration-500 hover:bg-primary-500" href="#">
                                        Order Now
                                    </a>
                                </div>
                            </div>
                        </div><!-- end grid-cols -->

                        <div class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300">
                            <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">
                                <div class="mb-4 mx-auto">
                                    <img class="w-full h-full group-hover:scale-105 transition-all" src="assets/steamed-dumpling-8d78cb15.png">
                                </div>

                                <div class="pt-2">
                                    <div class="flex items-center justify-between mb-4">
                                        <a class="text-default-800 text-xl font-semibold line-clamp-1 after:absolute after:inset-0" href="#">Steamed
                                            Dumpling</a>
                                        <span class="inline-flex items-center gap-2 mb-4">
                                        <span class="bg-primary rounded-full p-1"><i class="h-3 w-3 text-white fill-white" data-lucide="star"></i></span>
                                        <span class="text-sm text-default-950 from-inherit">100 Gram</span>
                                    </span>
                                    </div>

                                    <p class="text-default-500 font-medium mb-3">It’s the perfect dining experience where every dish is crafted with fresh, high-quality ingredients and served by friendly staff who go.</p>
                                    
                                   

                                    <a onclick="document.getElementById('id01').style.display='block'" class="relative z-10 w-full inline-flex items-center justify-center rounded-full border border-primary bg-primary px-6 py-3 text-center text-sm font-medium text-white shadow-sm transition-all duration-500 hover:bg-primary-500" href="#">
                                        Order Now
                                    </a>
                                </div>
                            </div>
                        </div><!-- end grid-cols -->

                        <div class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300">
                            <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">
                                <div class="mb-4 mx-auto">
                                    <img class="w-full h-full group-hover:scale-105 transition-all" src="assets/veg-rice-e40004d1.png">
                                </div>

                                <div class="pt-2">
                                    <div class="flex items-center justify-between mb-4">
                                        <a class="text-default-800 text-xl font-semibold line-clamp-1 after:absolute after:inset-0" href="#">Indian
                                            Food</a>
                                        <span class="inline-flex items-center gap-2 mb-4">
                                        <span class="bg-primary rounded-full p-1"><i class="h-3 w-3 text-white fill-white" data-lucide="star"></i></span>
                                        <span class="text-sm text-default-950 from-inherit">100 Gram</span>
                                    </span>
                                    </div>

                                    <p class="text-default-500 font-medium mb-3">It’s the perfect dining experience where every dish is crafted with fresh, high-quality ingredients and served by friendly staff who go.</p>
                                    
                                   

                                    <a onclick="document.getElementById('id01').style.display='block'" class="relative z-10 w-full inline-flex items-center justify-center rounded-full border border-primary bg-primary px-6 py-3 text-center text-sm font-medium text-white shadow-sm transition-all duration-500 hover:bg-primary-500" href="#">
                                        Order Now
                                    </a>
                                </div>
                            </div>
                        </div><!-- end grid-cols -->

                        <div class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300">
                            <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">
                                <div class="mb-4 mx-auto">
                                    <img class="w-full h-full group-hover:scale-105 transition-all" src="assets/chickpea-hummus-cb6f1463.png">
                                </div>

                                <div class="pt-2">
                                    <div class="flex items-center justify-between mb-4">
                                        <a class="text-default-800 text-xl font-semibold line-clamp-1 after:absolute after:inset-0" href="#">Chickpea
                                            Hummus</a>
                                        <span class="inline-flex items-center gap-2 mb-4">
                                        <span class="bg-primary rounded-full p-1"><i class="h-3 w-3 text-white fill-white" data-lucide="star"></i></span>
                                        <span class="text-sm text-default-950 from-inherit">100 Gram</span>
                                    </span>
                                    </div>

                                    <p class="text-default-500 font-medium mb-3">It’s the perfect dining experience where every dish is crafted with fresh, high-quality ingredients and served by friendly staff who go.</p>
                                    
                                   

                                    <a onclick="document.getElementById('id01').style.display='block'" class="relative z-10 w-full inline-flex items-center justify-center rounded-full border border-primary bg-primary px-6 py-3 text-center text-sm font-medium text-white shadow-sm transition-all duration-500 hover:bg-primary-500" href="#">
                                        Order Now
                                    </a>
                                </div>
                            </div>
                        </div><!-- end grid-cols -->

                        <div class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300">
                            <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">
                                <div class="mb-4 mx-auto">
                                    <img class="w-full h-full group-hover:scale-105 transition-all" src="assets/butter-cookies-62bc5f5a.png">
                                </div>

                                <div class="pt-2">
                                    <div class="flex items-center justify-between mb-4">
                                        <a class="text-default-800 text-xl font-semibold line-clamp-1 after:absolute after:inset-0" href="#">Butter
                                            Cookies</a>
                                        <span class="inline-flex items-center gap-2 mb-4">
                                        <span class="bg-primary rounded-full p-1"><i class="h-3 w-3 text-white fill-white" data-lucide="star"></i></span>
                                        <span class="text-sm text-default-950 from-inherit">100 Gram</span>
                                    </span>
                                    </div>

                                    <p class="text-default-500 font-medium mb-3">It’s the perfect dining experience where every dish is crafted with fresh, high-quality ingredients and served by friendly staff who go.</p>
                                    
                                   

                                    <a onclick="document.getElementById('id01').style.display='block'" class="relative z-10 w-full inline-flex items-center justify-center rounded-full border border-primary bg-primary px-6 py-3 text-center text-sm font-medium text-white shadow-sm transition-all duration-500 hover:bg-primary-500" href="#">
                                        Order Now
                                    </a>
                                </div>
                            </div>
                        </div><!-- end grid-cols -->
                    </div><!-- end grid -->
                </div>
            </div>
        </div>
    </section>
<div id="id01" class="w3-modal">
  <div class="w3-modal-content">
    <div class="w3-container">
      <span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span>
      <div class="lg:col-span-3">
        <form>
          <div class="grid lg:grid-cols-2 gap-6">
            <div class="lg:col-span-2">
              <label class="block text-base/normal text-default-950 mb-2" for="e_mail">Days</label>
              <select class="block w-full rounded-full py-2.5 px-4 bg-white border border-default-200 focus:ring-transparent focus:border-default-200 dark:bg-default-50">
                <option>Monday</option>
                <option>Tuesday</option>
                <option>Wednesday</option>
                <option>Thursday</option>
                <option>Friday</option>
                <option>Saturday</option>
                <option>Sunday</option>
              </select>
            </div>
            <div class="lg:col-span-2">
              <label class="block text-base/normal text-default-950 mb-2" for="e_mail">Quantity</label>
              <input id="e_mail" class="block w-full rounded-full py-2.5 px-4 bg-transparent dark:bg-default-50 border border-default-200 focus:ring-transparent focus:border-default-200" type="text" placeholder="Enter your Quantity In Gram">
            </div>
            <div>
              <a href="javascript:void(0)" class="inline-flex items-center justify-center px-10 Tuesday-3 rounded-full text-base font-medium bg-primary text-white capitalize transition-all hover:bg-primary-500" style="padding:10px 30px 10px 30px">Submit</a>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div> 
<?php
    require_once("footer.php")
?>