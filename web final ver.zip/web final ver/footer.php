<footer class="border-t border-default-200" style="background: #e2c1a6;">
    <div class="container">
        <div class="grid lg:grid-cols-3 items-center gap-6 lg:py-10 py-6">
            <div class="lg:col-span-2">
                <div class="grid md:grid-cols-4 grid-cols-2 gap-6 mb-6 main_width" style="width: 1000px;">
                    <div class="flex flex-col gap-3">
                        <a href="index.php">
                            <h2 >MEALS 4 U</h2>
                        </a>
                        <p class="text-sm text-default-500 mb-6 text-dark"></p>
                        <div class="flex items-center gap-4">
                            <a href="#!" class="cursor-pointer">
                                <i data-lucide="phone" class="h-6 w-6 transition-all text-default-600 hover:text-primary"></i>
                            </a>
                            <a href="#!" class="cursor-pointer">
                                <i data-lucide="globe" class="h-6 w-6 transition-all text-default-600 hover:text-primary"></i>
                            </a>
                            <a href="#!" class="cursor-pointer">
                                <i data-lucide="instagram" class="h-6 w-6 transition-all text-default-600 hover:text-primary"></i>
                            </a>
                            <a href="#!" class="cursor-pointer">
                                <i data-lucide="twitter" class="h-6 w-6 transition-all text-default-600 hover:text-primary"></i>
                            </a>
                        </div>
                    </div>
                    <div class="flex flex-col gap-3">
                        <h5 class="mb-3 font-semibold text-default-950">Support</h5>
                        <div class="text-default-600"><a href="#">Home</a></div>
                        <div class="text-default-600"><a href="#">About Us</a></div>
                        <div class="text-default-600"><a href="#">Menu</a></div>
                       
                        
                    </div>

                   
                </div>
            </div>
            <div class="col-span-1">
                <div class="flex flex-col gap-3">
                    <div class=" rounded-lg">
                        <div class="p-8">
                            <form class="space-y-2 mb-6">
                                <label for="subscribefEmail" class="text-lg font-medium text-default-950 mb-4">Subscribe</label>
                                <div class="flex rounded-md shadow-sm">
                                    <input type="email" id="subscribeEmail" name="subscribeEmail" class="py-3 px-4 block w-full bg-white border-default-200 rounded-s-md text-sm dark:bg-default-50" placeholder="Email address" />
                                    <button type="button" class="inline-flex flex-shrink-0 justify-center items-center h-[2.875rem] w-[2.875rem] rounded-e-md border border-transparent font-semibold bg-primary text-white hover:bg-primary-500 transition-all text-sm">
                                        <i data-lucide="arrow-right" class="h-5 w-5"></i>
                                    </button>
                                </div>
                            </form>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="py-6 border-t border-default-200 lg:flex hidden">
            <div class="container">
                <div class="grid lg:grid-cols-2 items-center gap-6">
                    <div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<div class="fixed lg:bottom-5 end-5 bottom-18 flex flex-col items-center bg-primary/25 rounded-full z-10">
    <button class="h-0 w-8 opacity-0 flex justify-center items-center transition-all duration-500 translate-y-5 z-10" data-toggle="back-to-top">
        <i class="h-5 w-5 text-primary-500 mt-1" data-lucide="chevron-up"></i>
    </button>

</div>




</body>


</html>
