<?php
require_once("header.php");
$id=$_GET['menu_id']; 
$time=$_GET['time'];

?>
<section class="lg:flex items-center hidden bg-default-400/10 h-14">
    <div class="container">
        <div class="flex items-center">
            <ol aria-label="Label123" class="flex items-center whitespace-nowrap min-w-0 gap-2">
                <li class="text-sm">
                    <a class="flex items-center gap-2 align-middle text-default-800 transition-all leading-none hover:text-primary-500"
                        href="index.php">
                        <i class="w-4 h-4" data-lucide="home"></i>
                        Home
                        <i class="w-4 h-4" data-lucide="chevron-right"></i>
                    </a>
                </li>


                <li aria-current="page"
                    class="text-sm font-medium text-primary truncate leading-none hover:text-primary-500">
                    add Menu
                </li>
            </ol>
        </div>
    </div>
</section>

<section class="lg:py-16 py-6">
    <div class="container">
        <div class="grid lg:grid-cols-1 gap-10">
            <div class="lg:col-span-3">
                <form method="post" action="action.php">
                    <div class="grid lg:grid-cols-2 gap-6">
                        <div class="lg:col-span-2">
                            <label class="block text-base/normal text-default-950 mb-2" for="e_mail">Days</label>
                            <select
                                class="block w-full rounded-full py-2.5 px-4 bg-transparent dark:bg-default-50 border border-default-200 focus:ring-transparent focus:border-default-200"
                                aria-label="
                                Default select example" name="day">
                                <option selected value="Monday">Monday</option>
                                <option value="Tuesday">Tuesday</option>
                                <option value="Wednesday">Wednesday</option>
                                <option value="Thursday">Thursday</option>
                                <option value="Friday">Friday</option>
                                <option value="Saturday">Saturday</option>
                                <option value="Sunday">Sunday</option>
                            </select>
                        </div>
                        <input type="date" name="date" class="form-control">
                        <!-- <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>"> -->
                        <input type="hidden" name="menu_id" value="<?php echo $id; ?>">
                        <input type="hidden" name="time" value="<?php echo $time; ?>">
                        <div>
                            <div>
                                <button href="javascript:void(0)" type="submit" name="save"
                                    class="inline-flex items-center justify-center px-10 py-3 rounded-full text-base font-medium bg-primary text-white capitalize transition-all hover:bg-primary-500">add
                                    day
                                </button>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
</section>


<?php
require_once("footer.php")
?>