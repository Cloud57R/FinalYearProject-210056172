<?php
require_once("header.php");

require_once("admin/database.php");
$query="SELECT * FROM meal WHERE time='Breakfast'";
$Breakfast=db::getRecords($query);

$query="SELECT * FROM meal WHERE time='Lunch'";
$Lunch=db::getRecords($query);

$query="SELECT * FROM meal WHERE time='Dinner'";
$Dinner=db::getRecords($query);

?>
<!-- Hero Section -->
<section class="lg:py-16 py-6 relative">
    <div class="absolute inset-0 blur-[60px] bg-gradient-to-l from-green-600/20 via-orange-600/5 to-green-600/0">
    </div>
    <div class="container relative">
        <div class="grid lg:grid-cols-2 items-center">
            <div class="py-20 px-10">
                <div class="flex items-center justify-center lg:justify-start order-last lg:order-first z-10">
                    <div class="text-center lg:text-start">
                        <span
                            class="inline-flex py-2 px-4 text-sm text-primary rounded-full bg-primary/20 mb-8 lg:mb-2">#Special
                            Food 🍇</span>
                        <h1
                            class="lg:text-6xl/normal md:text-5xl/snug text-3xl font-bold text-default-950 capitalize mb-5">
                            We Offer <span class="inline-flex relative">
                                <span>Delicious</span>
                                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUoAAAB+CAMAAAB1a6g4AAAAQlBMVEUAAAD2giD0gSD2gCD1gCD1giDzgCD1giD0gSD0giD2gyD1gSD0gyD1gyDzgCD0gCD2gyD0gSD2gyD0gSD2giD1giDiNqzxAAAAFXRSTlMA34AQIJ9A72Bwv5C/z1Awr6Bvv3B3eDZRAAAHf0lEQVR42u2d7XaiMBRFucnNdwJx2vv+rzoJaZsqWkSpBc3+MYNrWdfq6bnZgArdVkCUUmvDmBAiWhsgo+gIBRmbSE9izGgt5YBdo+MotUnRWQCqAEDwPoqMY0c4kfEJOP6RYKNgppcD714KHLRxIsBXdD5XLDcMkS/7Uwy5yanI0deXs9GlUJ+7q3zQTFigjEr5OaMl8jVfX/ap5D6oj0wF6+WT1XTMMKgyioLpfibANULVLHqghArxKRJNIboIlIA8dvho7QzSOB9KR53ea6DYszFEFUTK8G+1M/Spo4qIckN3tYpi76wiIsghbkc7OdDcUGXdHvLk0sTxzy/MwLeoHS7NYcwzmg3PO9culC4OfOPa+cgzbLGeKUYgUt5JPqOdBzGvHS6ZV3l+NhQn7x2MEzPMaOfhzGtHmlji3MCwS2ZzG81wTjt/H+I12hlMjtmmX+Hv4L1QRJ7Js9rZ5vHwBe1I54ngj8rJjVWkhOYT7Ww1xRntoD7kcuoHz1HKkQicnGpnw3sYiTntSAcPTTPlWMZ6qp3dMdXOYMKD0uT9mCOeaGePMV7UDuY0o+5+FekUKSYn2tk9p9oZHKSHsludOtjKyRPt7GZtnGGiHZkewuej1QvpDT/SzhPUsTLVDteeSKy9dPW1kDnHJxnrCRPt4EGlBytONlMUDP+unQ0dxKzKVDtcQ57z1YL08pt2nrWPlRPt9D5t40pBVu083/o4ZaodPBAJvDtIgd+08zS+nqdqp4a5RpD9SxWyUrWTwwR2Y5X+pRril3Zeq5CVqp0xzFtsLi15+bVavmAhK1U7mLaGbhlcEPQtyMTJSqkhbSybbcX452r51PuQy8NkS6YcLXlsQVaOtYNvFPHqSppP7bQgK1U7Rl1VTC5KgNK2NXLCqJ1STMFnnwxkvrTTOKFqhxHgzDMVyA/tvOh+5M9U7Qyg3n9+msesnbZIXqJqBwOx7iKC3Kd2Gpeo2nHkLgkn5pi5aJX8maodRpGfTTKQGbXTKjnLp3YMhXNZBtKjdtoe0FUU7ehzWYqcJGvDfTVFO5rEtLCsaKdxLUU77DSzf8SKdhoLGLXD6P2orBSTdppwFlK086aGb/IGwFE7jUUU7XAA/m3oZSdakssp2pF1ucS0ydo6eRuM3FjFggf815K8laQdrmzZlqSzdho3krRjSH6UkgO0PfOb4QAftUTSjtrR4h1IcmxMUJBsBzn34ahXOUKIvo33fXBl31TXDdT2KO/GkKAh/QvQNe5EBTJdpFbK+2FEovNEbaW8G64odND2ztfgjaBr870Kmqhr870KPEfZ/L0KQB3YrrECETpo1lkFD23A1xtwovaRtRVAorYztN7OEFDzzgpEgi6QahO+xnzb7kDtHbJV5jt2hoLqGncCQGY89fveNe5Cj6d+O2Xf2mp5Hwg2Qvrfqb69TXYfjiSJ8a1H1t68vQtJThN2iTTfAG3EbwYBONiPUN8H1fbTbyYS6nGsSy1N27m8FUYGwdZZ71zL8tYkWQoPvxmoO7TTGreg6TBW8ZOsHd4+QH1TkqHDI2ln7fDQjnqW8o8Cz9rpvmHal01u/7KJ6b5TtOPaYc8SHB2Kdo4p2mEU2rviV4KWWNHOKUU7RsGOr9r7SCQoXbQzpWgHoS2Y1wkHsGjnh6/WH8i2IZ8f7gP/0M55inY0qLZXNH8lpqKdixTtYGzFnL04WNHOZT61o9uKeQnOSiWLdi7zpR08ELTjyDP0QIJ/audHqnYGaFN+8aKeRTtzVO1oaNcJPF0klanamadqh7MWZgUFKcardq6iagcP1MI8DrJoZwGjdlqYdY3MQVbtLKJqBw9p66UvwFiCrNpZTNUOpi14nrvBLIObkIOs2lnOsXa0J/WKcz7eo6A/Xi2Xc7JSDmnTvlY1600zJkHeFWaZcyVe5iMx9aYZdbW8g1PtyLQN7gVODkumxkKuGeREOzoSBfPUyyYyS+R7fqSdNZhoB9MDCnu+3eDsTXzLYFftrEvVTknzeW/zlnKcaGddqnZqmkropxl1roUilXKcaGd1ptrhfXpI9hnKOY61Ej2faOe3mGpnMLmcds8r52BsuUnqRDu/TdVOLWcYbx+8w3YO4+2DwfV8op3HMNUOljgt29NNrZ0dY9R8qp2HMtUO9i4QURCbrycfjAAiCjnGqXYeyWXtcJkmpuS5zX7mFAOV9Yhf0M7jmWqn1tOPeUbWb0hH2JcuKu96PNbOVu7NfV472LMYKMf894HmEIMiIoisx7Pa2c4IXdAOl9p5oESwzsiHJ5oydBFoDNHpgZ/VzgbPHF7UDpe5oYoSkDqqZfqdfhWOvWYiACVUECyFeF47W4xxXjslUVE6SipYwUy/aqgcpTZOWFCUAT9meFE7G/Vi4nrtoMxjlzItQLBRMKa1lAPyZdmhlFozJlJ+9eWEM3rAn7WzqzMHV2iHDylUJqIPQBUAsAmRcewIJzLR2gBw/CNepJJriXxWO/tK8Sbt4JAbZnLFhE9ARtERCjLB+yhSdMzkJiNer50dTPSEjWtn92xCO8/FQ7Sz0xVxAb+tnecu4YSVtbOZ/v0H4aWQ+jK6GMsAAAAASUVORK5CYII="
                                    class="absolute -z-10 h-full w-full lg:flex hidden">
                            </span>
                            <span class="text-primary">Food</span>
                        </h1>
                        <p class="text-lg text-default-700 font-medium mb-8 md:max-w-md lg:mx-0 mx-auto">Imagine making your diet quick and easy, with our online meal plan you can do so!.</p>
                        <div class="flex flex-wrap items-center justify-center lg:justify-normal gap-5 mt-10">
                            <a href="user/index.php"
                                class="py-5 px-10 font-medium text-white bg-primary rounded-full hover:bg-primary-500 transition-all">Order
                                Now</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end grid-col -->
            <div class="relative flex items-center justify-center py-20">
                <span class="absolute top-0 start-0 text-3xl -rotate-[40deg]">🔥</span>
                <span
                    class="absolute top-0 end-[10%] -rotate-12 h-14 w-14 inline-flex items-center justify-center bg-yellow-400 text-white rounded-lg">
                    <i data-lucide="clock-3" class="h-6 w-6"></i>
                </span>
                <!-- end icons && img -->
                <img src="assets/hero-f578fbc8.png" class="mx-auto">
            </div>
            <!-- end grid-col -->
        </div>
        <!-- end grid -->
    </div>
    <!-- end container -->
</section>
<!-- About Us Section -->
<section class="lg:py-16 py-6" id="about">
    <div class="container">
        <div class="grid lg:grid-cols-2 items-start gap-10">
            <div class="flex items-center justify-center h-full w-full bg-default-500/5 rounded-lg">
                <img src="assets/about-us-d5778dfe.png" class="h-full w-full">
            </div>
            <div class="">
                <span class="inline-flex py-2 px-4 text-sm text-primary rounded-full bg-primary/20 mb-6">About Us</span>
                <h2 class="text-3xl font-semibold text-default-900 max-w-xl mb-6">Where quality food meet Excellent
                    services.</h2>
                <p class="text-default-500 font-medium mb-3">Our website is the perfect solution to all of your dieting problems.</p>
                <p class="text-default-500 font-medium mb-3">By signing up today you can start tracking all of your meals and how much water you are drinking on a daily basis.</p>
                <p class="text-default-500 font-medium mb-3">Its free to sign up and will never cost you a penny after you have signed up, click below to get started.</p>
                <div class="flex flex-wrap items-center md:justify-start justify-center gap-4 mt-10">
                    <a href="#cus_menu"
                        class="py-3 px-10 font-medium text-white bg-primary rounded-full hover:bg-primary-500 transition-all">Get
                        started</a>
                </div>
                <!-- end flex -->
            </div>
        </div>
    </div>
</section>
<!-- Menu Section -->
<section class="lg:py-16 py-6" id="cus_menu">
  <div class="container">
    <div class="grid lg:grid-cols-4 lg:gap-10 gap-6">
      <div>
        <div>
          <span class="inline-flex py-2 px-4 text-sm text-primary rounded-full bg-primary/20 mb-6">Menu</span>
          <h2 class="text-3xl font-semibold text-default-900 mb-6">Special Menu for you...</h2>
      </div>
      <div class="flex flex-wrap w-full">
          <div class="lg:h-[30rem] h-auto lg:w-full w-screen custom-scroll overflow-auto lg:mx-0 -mx-4 px-2">
            <nav class="flex lg:flex-col gap-2" aria-label="Tabs" role="tablist" data-hs-tabs-vertical="true">
              <!-- Coffee Menu Tab Button -->
              <button type="button" class="flex p-1 active" id="breakfast-menu-item" data-hs-tab="#breakfast-menu" aria-controls="breakfast-menu" role="tab">
                <span class="hs-tab-active:bg-primary text-default-900 flex items-center justify-start gap-4 p-2 pe-6 lg:w-2/3 w-full transition-all hover:text-primary rounded-full">
                  <span class="hs-tab-active:bg-white h-14 w-14 inline-flex items-center justify-center rounded-full">
                    <img src="assets/cup-3dff3c2f.svg" class="h-8 w-8">
                </span>
                <span class="hs-tab-active:text-white text-base font-medium">Breakfast</span>
            </span>
        </button>
        <!-- Burger Menu Tab Button -->
        <button type="button" class="flex p-1" id="lunch-menu-item" data-hs-tab="#lunch-menu" aria-controls="lunch-menu" role="tab">
            <span class="hs-tab-active:bg-primary text-default-900 flex items-center justify-start gap-4 p-2 pe-6 lg:w-2/3 w-full transition-all hover:text-primary rounded-full">
              <span class="hs-tab-active:bg-white h-14 w-14 inline-flex items-center justify-center rounded-full">
                <img src="assets/burger-1-0c3ba5a6.svg" class="h-8 w-8">
            </span>
            <span class="hs-tab-active:text-white text-base font-medium">Lunch</span>
        </span>
    </button>

    <!-- Burger Menu Tab Button -->
    <button type="button" class="flex p-1" id="dinner-menu-item" data-hs-tab="#dinner-menu" aria-controls="dinner-menu" role="tab">
        <span class="hs-tab-active:bg-primary text-default-900 flex items-center justify-start gap-4 p-2 pe-6 lg:w-2/3 w-full transition-all hover:text-primary rounded-full">
            <span class="hs-tab-active:bg-white h-14 w-14 inline-flex items-center justify-center rounded-full">
                <img src="assets/burger-1-0c3ba5a6.svg" class="h-8 w-8">
            </span>
            <span class="hs-tab-active:text-white text-base font-medium">Dinner</span>
        </span>
    </button>


</nav>
<!-- end tab -->
</div>
</div>
</div>
<div class="lg:col-span-3">
    <div class="relative lg:mt-24">
        <div class="bg-primary/10 rounded-lg lg:pb-16">
            <div class="lg:p-6 p-4">







                <div id="lunch-menu" class="hidden" role="tabpanel" aria-labelledby="lunch-menu-item">
                    <div class="grid grid-cols-1">
                        <div class="swiper menu-swiper w-full h-full">
                            <div class="swiper-wrapper">

                                <?php
                                if($Lunch)
                                {
                                    foreach($Lunch as $lunc)
                                    {
                                        ?>
                                        <div class="swiper-slide">
                                            <div class="relative rounded-lg overflow-hidden cursor-pointer">
                                                <img  src="admin/uploads/<?php echo $lunc['image']; ?>"
                                                class=" w-full">
                                                <div class="absolute inset-0 bg-default-950/20">
                                                    <div class="inline-flex items-end h-full w-full">
                                                        <div class="p-6">
                                                            <h5 class="text-xl font-medium text-white mb-2">
                                                                <?php  echo $lunc['name'] ?></h5>
                                                                <h5 class="text-xl font-semibold text-white mb-2">
                                                                    <span
                                                                    class="text-base font-medium text-yellow-400"></span>
                                                                    100 Gram

                                                                </h5>
                                                                <button
                                                                onclick="document.getElementById('id01').style.display='block'"
                                                                class="inline-flex items-center text-white border-b border-dashed border-white"><a
                                                                href="meal_detail.php?id=<?php  echo $lunc['id'] ?>">C
                                                            Menu</a>
                                                            <i data-lucide="chevron-right" class="h-5 w-5"></i>
                                                            <a
                                                            href="add_to_menu.php?menu_id=<?php  echo $lunc['id'] ?>&time=<?php  echo $lunc['time'] ?>">add
                                                        to menu</a>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php

                            }
                        }
                        ?>
                    </div>
                </div>
                <!-- end pizza menu slider -->
            </div>
            <!--end grid-->
        </div>







        <div id="breakfast-menu" role="tabpanel" aria-labelledby="breakfast-menu-item">
            <div class="grid grid-cols-1">
                <div class="swiper menu-swiper w-full h-full">
                    <div class="swiper-wrapper">
                        <?php
                        if($Breakfast)
                        {
                            foreach($Breakfast as $break)
                            {
                                ?>
                                <div class="swiper-slide">
                                    <div class="relative rounded-lg overflow-hidden cursor-pointer">
                                        <img src="admin/uploads/<?php echo $break['image']; ?>"
                                        class="h-full w-full">
                                        <div class="absolute inset-0 bg-default-950/20">
                                            <div class="inline-flex items-end h-full w-full">
                                                <div class="p-6">
                                                    <h5 class="text-xl font-medium text-white mb-2">
                                                        <?php  echo $break['name'] ?></h5>
                                                        <h5 class="text-xl font-semibold text-white mb-2">
                                                            <span
                                                            class="text-base font-medium text-yellow-400"></span>
                                                            100 Gram
                                                        </h5>
                                                        <button
                                                        onclick="document.getElementById('id01').style.display='block'"
                                                        class="inline-flex items-center text-white border-b border-dashed border-white"><a
                                                        href="meal_detail.php?id=<?php  echo $break['id'] ?>">C
                                                    Menu</a><i data-lucide="chevron-right"
                                                    class="h-5 w-5"></i>
                                                    <a
                                                    href="add_to_menu.php?menu_id=<?php  echo $break['id'] ?>&time=<?php  echo $break['time'] ?>">add
                                                to menu</a>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    ?>


                    <!-- end slide -->
                </div>
                <!-- end pizza menu slider -->
            </div>
        </div>
        <!--end grid-->
    </div>




    <div id="dinner-menu" class="hidden" role="tabpanel" aria-labelledby="dinner-menu-item">
        <div class="grid grid-cols-1">
            <div class="swiper menu-swiper w-full h-full">
                <div class="swiper-wrapper">

                    <?php
                    if($Dinner)
                    {
                        foreach($Dinner as $dinn)
                        {
                            ?>
                            <div class="swiper-slide">
                                <div
                                class="relative rounded-lg overflow-hidden cursor-pointer">
                                <img style="height: 450px !important" src="admin/uploads/<?php echo $dinn['image']; ?>"
                                class="w-full">
                                <div class="absolute inset-0 bg-default-950/20">
                                    <div class="inline-flex items-end h-full w-full">
                                        <div class="p-6">
                                            <h5
                                            class="text-xl font-medium text-white mb-2">
                                            <?php  echo $dinn['name'] ?></h5>
                                            <h5
                                            class="text-xl font-semibold text-white mb-2">
                                            <span
                                            class="text-base font-medium text-yellow-400"></span>
                                            100 Gram
                                        </h5>
                                        <button
                                        onclick="document.getElementById('id01').style.display='block'"
                                        class="inline-flex items-center text-white border-b border-dashed border-white"><a
                                        href="meal_detail.php?id=<?php  echo $dinn['id'] ?>">C
                                    Menu</a><i
                                    data-lucide="chevron-right"
                                    class="h-5 w-5"></i>
                                    <a
                                    href="add_to_menu.php?menu_id=<?php  echo $dinn['id'] ?>&time=<?php  echo $dinn['time'] ?>">add
                                to menu</a>

                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}
?>
</div>
</div>
<!-- end pizza menu slider -->
</div>
<!--end grid-->
</div>


</div>
</div>
<div class="lg:flex items-center gap-1 absolute !-top-10 !end-15 hidden">
    <div class="swiper-button-next after:content-[] h-12 w-12 flex justify-center items-center rounded-full text-white bg-primary transition-all">
        <i class="fa-solid fa-angle-left"></i>
    </div>
    <div class="swiper-button-prev after:content-[] h-12 w-12 flex justify-center items-center rounded-full text-white bg-primary transition-all">
        <i class="fa-solid fa-angle-right"></i>
    </div>
</div>
<div class="lg:flex hidden">
    <div class="swiper-pagination !bottom-12 !start-0"></div>
    <span class="absolute bottom-0 start-1/4 z-10">
        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHYAAABACAMAAAD4WnOTAAAC+lBMVEUAAACtcY6qc4+TQGuydpbEiKGwfZS/dZHOhKGwbojBfJbJg6C6dZDBgZmgXHm5epOjVIO5fpXDe5bQiqazcY2dR3/PjKidWX7PjqiWSHegV4GVTXueVn63fZqRTnO8dpKZOHrMgZ2jTofHepetbYmeSoPblrDQkau9fZa/a4y2SpiqQY6iRoOXPHjOg6KORW/TiaWwTZSeW3u4d5OeOn+lYX6lQYqtUprr0c7bsLfqzszdvLvx3djXqLHs1dHlysjfw8Hbub7jxsPTp6zu2NTpysrIm6Ozcozrx8vWrLDv1tLoxsjkyMbnx8Xkw8Tlv8TkwcHTqLDNo6e8jJPpysjhxcHdv77On6nOkaa6h5WhO4Xz39ngtr/etbjXr7e3Rpm2iJDmzMnow8fiu8LbtLvavLrXtbXTsLXTo63DiZ29kZq+jpa6e5Lv2tXt0s/YubzXtLnYt7bbrrTSrq7Ilp2+hJW3dI+1fo6yhIysaoWgNoDz0dLuzc7sy83nzcvnw8PgwMLfuLrWrLTPp6rNnqXDk5/Gi5zFhZy/lpu/i5vHfpm/fJW6gpK3eY2paIHv0tPpv8bgwL7YurjXsLLMm6jMjaTIlKLJiKG9iJitcoexaIWsWYOULnDx2dXo0M3yyczfvMLiuL3Us7LPrq7HoqPMm6PHjaLCmJ/EjZ/Dj5m8eJC2hI+weoqrZIH12Njixsffur7fsbrQrbLRmqzNq6rHn6XGmaLKkKC6f5Wwf4myaoemN4OdMHr14dzy1dTzzdHuw8rgwsXnu8Pes7zksrzas7bOo6vLpqrToqrNlqjRm6bFnKDKgp3Dgpu/gJnBk5jCh5i1Q5OqPImlO4mteIalYnuTNW/11tXqtMXlvb/CTqrIj52+hZq+go+sP46aM4GWMniJLGHXm7DTl6rFk6TMlaDDlpu3boqyY4erdYKdPHv26OT05d/029jsu8TcvcHepbm8SqHFeJSxQJC4S5a4jJShVnjXn7GnToSiRIKZTXKNKme3QZy5dIJl/CJjAAAAOHRSTlMADQb+IDgV/vz+vamjenRcUkPz8ey8upSJhGJDOSgg+fjw7uHf29rOTf768evp3Lj91c/MxcO8gy2iQi8AAAm3SURBVFjD7ZfVdxQHFIcJgQYrLXV3d+/Murt71shKspvduLu7e0LcPcRdiLsRIykJBJdipVDvOR36B/ScDaFP+Z7m7Tv3zv3dO7Nrhx122GGHHXbYYYcd/jfM9hx56fDhw8+/ePilVx4z2/V/YPbqE4e+fib2dXJdXXZXtvf+d749/NruXY8WsyOPH3jqdfL+BIjlX5aXlxPIHh77n3n+tV2Pjt17X3j/6dnqLu9j5GP/ci3hmHfCcoKHh8c7L+96NOx+7PEDb2bOko+RO8IzMsLDLR+QFZ3lWXssgTzT8cyT26+EpEcOvR1TTY53z8qyjMuy9Ky9tnRtacmy8uLF6Oh1coK3h8cj8Jp9cOApi9j4WFvb6E7PGiuDwVBR0Wrw6rxWWxMdnpHleczb287unVe2udIPDrx+xSM20j0uztBG4o41Oep0TjpdU9PY1H2vzqW46OiOWsgb/9Vr2yndc3DflerIefe48DQu9gFOWmWI0snR0THIqamktc3Tc929o8PbI5b8+fYl+LEn3raYyTw9XxPOxRZqCpXcNoOVl1VnDX9UGeT4wK0LX/K0LbclL8fa/fHiduV374GnPCIl7pZi7O1CeQjJYGhrnRorKY0yRHl1hiudbg/c1rVa1kZXrtvtJ8/Wmb+8PaU+/mZ1rG1WhlgXxFJmGMNbQ52dbVKsU4pbXCF1p5WTY339bSxpKfrixfLZhFhv821p85GDd6sjIyxJ2qAGKomHd2JhMEIhBsI6xbmkZSzKyzJkYGCgcMzK8+LExLp3V5e5+UsPn5oXno5xj3QXO2kKeUYSloVhoOshsUgkwsBTnG2KXVuivGpA7G1sU0Vt5USz7f6urj9Wnn3Ycl99bnom/XQ0t5DNrcCPYFSMZGsbV97U5culvGLXYqjV1iUtpVb3m5ywTqOWWZCWnFD9y7lPHzK8T3wWE5sZx5UXhlzmweloBjx0bs44NTXHh8bYq5PvmgIXweElrV5tSixWaVmbkbEe7w1pV55/qLBCDZ6xjVayh8JabYRE2BovNBWeDMelpDi3tOCnoGkKtRFhRI66qJoQLVYXXptRadtRd+WPcyvvPvYQE3xwX2x6eZqWPe7migYCmKmkYBhAQKHy81EYa2tn55YoK36JaAAnKqmoETtpmyquzVeWd9Rlm59beePJh3mtdunzaRq2mxs8AMaiTilgefb2BMhLAxg4YTK8uDjUq8IxqF5k42oIV2J1FUvulbZ2dV3m53Kvb7nLe9+fjmw+Lcayw8KCYIyROSoOgUDYo2D5ASoVmoHG4XBCjGuUsQlbX+84dt+yARtqWKqFtMtXoWp/f3b3Fq3v7ZMg2+XqNRKIBphUBRr1QOoPTuqRLiAXqYAnMxmMlFIvEnagXqQzVLmMKKG9XDlPrrtq/mfu7++abdEak97cPkQJLHMJAFiuI3k37Qn+DZMRG+4b7nGeGxsbVSNQgm1KDVbY+gB0k9Xfk2CI2HO9fN0j++q53Nzrb+3ZolVyvl1OZ7uF+AMcfCABQfBDtl8ax6dS8aGhPHyom6cYjhFBGebr0IziUq9rbiCYVmtbPptt8cufuT1b0+55P+bCrxGjdLUYSYQpeEwEAqUpm0QWJXNwyRwhHA63cTVW6UQYYfKYFxdj7TxmZdQ7hWS5T0jssrtWcnN9fLaiNXtuX/qd9rRCtZjqAEsNYyEIMJdxUMMSoIkCFaBCo4VCeCtfZ43DwVusRh1FIhurNqWcGxcBLakrObmbmz7ST17dwpb4Iub8RJpGTSIxHWx4RIK9QI9fa6AT6QIBzAGACMDBbYx4SCt0vU+1hju31oi1mrR4KLXe2eZ/bp6VSj8xvdrH98VIJtrY7LRRpiAVDxAI/njkSJGLy2CSOhASQ9siH52cyoe0DPiUQSuyLjEaQ7TIuHhJul1dzkrups+i9F2TA/TB0zGS5iyQrQ8hwkBegD2ByAMbFC6Nt/oHG12K1IkoAMhHi1z5qRgGI5k0OoDGFfPD5FpxfKwk8sqV38729PhIpSbnds9n0BBbgmqk3t+hkKdCIGBccK1ouN/P1/dEQdLwr+ybKBSgwvHm4ESYSmHU5gPoUCNXq7wYLym3q7sqPQt5pdIXTR2ng9PTv1bqKQ3ceoDOpff2JoIK9dpwgW/f8eOnTpzoXx3soxEAXCqfylQxUqLaCvNVxfwMUA66dzRLyDm/nz0r7e7xeeNlU0/dvruSC9FyNZfiQMdTaTKaFqRwiiCrr+8D7a3BxDwETQUnkVgoFK7USkuEDUTxkdohfXyEJDI7ZzP3rM+iT8+nr5l4dZ67m3lhPoStRxL9XNZQCEBB5XAa+wtOFJyCvMeTkm7KZAhUMp4UlA8IW/g8jEpVXKMfGkqLm5eUk6/+tpnb070g7XnR5CmePn+aS5FPsmEKPE1GKEKqmYrBggLf472QlULp/fHHGzJOWFlQQIDQOYrfwGDAK0bl8tEsu0zb2bocqY+PT/fCoqk93vuUxYXmNDZFnJRIcQuSIYhhGjobLOj37e0lHO874XcTshI4JOgmOQQIS/g8Fhpqd7AGWRWfXj7blSOVLi52Q9pvzEybp0MWmXci5HRNeFJiERWwB5BhgYHy4aT+U7Kbp3z7+/JkP97IE3DFdAcaCkiZ4zWg0dTT1OCQjPh2SSQ557p08cyZhe6Fj0088kfevHtnImNI7aL38ysLptEC3VxYrKLVW7cKTp3op5+SyXpvyGCpYhZAsCcElOLpiX7Bl8JAUB83kx7psWy+KT3z88mfu7u/My20uw/ePb8agaRQysDEpDJ1IgCWcZiBgUXDwwW3Bv37ZDd6oe0cPE6nQVJMaEWDH5NqdAPlQ2nxmZke2b+tXF/8+ejRkwvdJha712J69cIltn9ju8afWkbsI16aDOYwiRSKvx8lkYZAyGQ0JjJMDT2hhKX8VBYrtaoK1MiRG9PpM9k51318Fo5CnDH1K/nQh3dW2xsp6nEx3Q/vQoQFXoJenIDo70DLgz4t7PNoDoHjZSzAXkbD8WqUQTjnuSqQrUFGzGZC1jMLZ6AWQ9qPXzExs2/HrA5HDCdpqgYT/d3wHAFTX+2m4DBh0AAh8vJQgEBRJubAAAdUcqiRSg+yucxHFiU1RsSmZ5Jz7v0FKSHtvY++N3VBfXhhVRLRmAReovRR2pEcgSAQWRUWLBQQ/WB5DjBYMN6NyoQBKqHzZXeQThyZMyKHGl0iqjPT7XLu/fATxElI/eUeE8/sIYvzd2aaB9n6Sb9EyunxNaYAzcJvjCuCOYEcZrBixG1SAZUKMJxJcY3+RM7lKiSo1M9XR0baXb33w7/8dPLoR//92/UPI16CrL2Sv88AAAAASUVORK5CYII=">
    </span>
    <span class="absolute -bottom-12 -end-0 z-10">
        <img src="assets/leaf-ed221ba8.png">
    </span>
</div>
</div>
<!-- end menu-sliders -->
</div>
</div>
</div>
<!-- end container -->
</section>



<!-- <div id="id01" class="w3-modal">
    <div class="w3-modal-content">
        <div class="w3-container">
            <span onclick="document.getElementById('id01').style.display='none'"
                class="w3-button w3-display-topright">&times;</span>
            <div class="lg:col-span-3">
                <form>
                    <div class="grid lg:grid-cols-2 gap-6">
                        <div class="lg:col-span-2">
                            <label class="block text-base/normal text-default-950 mb-2" for="e_mail">Days</label>
                            <select
                                class="block w-full rounded-full py-2.5 px-4 bg-white border border-default-200 focus:ring-transparent focus:border-default-200 dark:bg-default-50">
                                <option>Monday</option>
                                <option>Tuesday</option>
                                <option>Wednesday</option>
                                <option>Thursday</option>
                                <option>Friday</option>
                                <option>Saturday</option>
                                <option>Sunday</option>
                            </select>
                        </div>
                        <div class="lg:col-span-2">
                            <label class="block text-base/normal text-default-950 mb-2" for="e_mail">Quantity</label>
                            <input id="e_mail"
                                class="block w-full rounded-full py-2.5 px-4 bg-transparent dark:bg-default-50 border border-default-200 focus:ring-transparent focus:border-default-200"
                                type="text" placeholder="Enter your Quantity In Gram">
                        </div>
                        <div>
                            <a href="javascript:void(0)"
                                class="inline-flex items-center justify-center px-10 Tuesday-3 rounded-full text-base font-medium bg-primary text-white capitalize transition-all hover:bg-primary-500"
                                style="padding:10px 30px 10px 30px">Submit</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div> -->
<?php
require_once("footer.php")
    ?>