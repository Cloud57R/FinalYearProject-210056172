<?php
require_once("header.php");
require_once("admin/database.php");
$query="SELECT * FROM foods";
$items=db::getRecords($query);


?>
<style>
    .section_hiden {
        display: none !important;
    }
    .heading{
        font-size: 1.25rem;
        line-height: 1.75rem;
        color: white;
        font-weight: 600;
        text-transform: capitalize;
    }
</style>
<!-- Menu Section -->
<section class="lg:py-16 py-6">
    <div class="container">
        <div class="grid xl:grid-cols-3 sm:grid-cols-2 gap-5 bg-primary/10 rounded-lg lg:pb-16" style="padding:30px">
            <?php
            if($items)
            {
                foreach($items as $item)
                {
                    ?>
                    <div class="order-3 border border-default-200 rounded-lg p-4 overflow-hidden hover:border-primary hover:shadow-xl transition-all duration-300"
                    style="background-image: linear-gradient(#cfc6c2e3, #0c0b0a6b), url('admin/uploads/<?php echo $item['image']; ?>');background-position: center;background-repeat: no-repeat;background-size: cover;border: none;height: 300px;">
                    <div class="relative rounded-lg overflow-hidden divide-y divide-default-200 group">


                        <div style="    padding-top: 150px;">
                            <div class="flex items-center justify-between mb-4">
                                <h1 class="heading"><?php echo $item['name']; ?></h1>
                            </div>

                            <p style="    color: hsl(0deg 0% 100%);" class="text-default-500 font-medium mb-3">
                                <?php echo $item['calories']; ?> Gram</p>
                                <?php
                                if(isset($_SESSION['user_id']))
                                {
                                    ?><a href="add_custom.php?id=<?php echo $item['id']; ?>" class="inline-flex items-center text-white border-b border-dashed border-white">C Menu <i data-lucide="chevron-right" class="h-5 w-5"></i></a><?php
                                }
                                else
                                {
                                  ?><a href="login.php" class="inline-flex items-center text-white border-b border-dashed border-white">C Menu <i data-lucide="chevron-right" class="h-5 w-5"></i></a><?php
                              }
                              ?>
                              
                            
                        </div>
                    </div>
                </div>

                <?php
            }
        }
        ?>
    </div>

</div>
</section>



<?php
require_once("footer.php")
?>