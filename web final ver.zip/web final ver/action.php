        <?php
        session_start();
        require_once("admin/database.php");
        $db = db::open();
        $datee = date("d-m-Y");
        // Register user
        if(isset($_POST['register'])) {
            $name = ($_POST['name']);
            $email = ($_POST['email']);
            $password = ($_POST['password']);
            $gender = ($_POST['gender']);
            $age = ($_POST['age']);
            $height = ($_POST['height']);
            $weight = ($_POST['weight']);
            $water_in_take = ($_POST['water_in_take']);
            $check_query = "SELECT * FROM user WHERE email = '$email' && password='$password'";
            $result =db::getRecord($check_query);
            if($result > 0) {
                echo "<script>
                alert('Email already exists.')
                </script>";
                echo "<script>  
                window.location = 'register.php';
                </script>";
            }else{
                $userinsert = "INSERT INTO `user` (`name`, `email`, `password`, `gender`,`age`,`height`,`weight`,`water_in_take`) VALUES
                ('$name','$email','$password','$gender','$age','$height','$weight','$water_in_take')";
                db::query($userinsert);
                echo "<script>
                alert('User Registered.')
                </script>";
                echo "<script>
                window.location = 'login.php';
                </script>";
            }
        }

        // Login User
        if(isset($_POST['login'])) {
            $email = $_POST['email'];
            $password = $_POST['password'];
            $query = "SELECT * FROM user WHERE email='$email' AND password='$password'";
            $rec = db::getRecord($query);
            if ($rec) {
                $_SESSION['user_id']=$rec['id'];
                $_SESSION['useremail']=$_POST['email'];
                header("location:user/index.php");
            } else {
                echo "<script>
                alert('Email and password do not match.')
                </script>";
                header('location:login.php');
            }
        }

        //save
        if (!isset($_SESSION['user_id'])) {

            echo "<script>
            alert('Please login.');
            window.location.href = 'login.php';
            </script>";
            exit();
        }

        if(isset($_POST['save'])) {
            $day = $_POST['day'];
            $user_id = $_SESSION['user_id']; ;
            $menu_id = $_POST['menu_id'];
            $time = $_POST['time'];
            $date = $_POST['date'];
            

            $userinsert = "INSERT INTO `custom_menu`(`user_id`, `day`, `menu_id`, `time`, `date`) VALUES ('$user_id','$day','$menu_id','$time','$date')";
                db::query($userinsert);
                echo "<script>
                alert('Added.');
                window.location.href = 'meal.php';
                </script>";
            
        }

        //add_custom_food
        if (isset($_POST['add_custom_food'])) {
            $days = $db->real_escape_string($_POST['days']);
            $time = $db->real_escape_string($_POST['time']);
            $food_id = $db->real_escape_string($_POST['food_id']);
            $user_id = $db->real_escape_string($_POST['user_id']);
            $meal_id = $db->real_escape_string($_POST['meal_id']);
            $date = $_POST['date'];
            $quantity = $_POST['quantity'];

            $query_insert = "INSERT INTO `custom_menu2` (`days`,`food_id`,`time`,`user_id`,`meal_id`,`date`,`quantity`) VALUES ('$days','$food_id','$time','$user_id','$meal_id','$date','$quantity')";
            db::query($query_insert);
            echo "<script>location='food.php'</script>";
        }