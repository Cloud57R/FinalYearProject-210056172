<?php
session_start();
if(isset($_SESSION['user_id'])){
     $user_id=$_SESSION['user_id'];

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Food Delivery</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="coderthemes" name="author" />
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <!-- Theme favicon -->
    <link rel="shortcut icon" href="assets/favicon-c43f27ef.ico">

    <!--  Head js -->
    <script type="module" crossorigin src="assets/home-c1b793e9.js"></script>
    <link rel="modulepreload" crossorigin href="assets/theme-b118ffc1.js">
    <link rel="modulepreload" crossorigin href="assets/free-mode-d251b1d1.js">
    <link rel="modulepreload" crossorigin href="assets/navigation-f8e75545.js">
    <link rel="modulepreload" crossorigin href="assets/thumbs-a96dec08.js">
    <link rel="stylesheet" href="assets/theme-c9540983.css">



</head>
<style>
@media (min-width: 320px) and (max-width: 450px) {
    .main_width {
        width: auto !important;
    }

    .main_btn {
        padding: 10px !important;
    }
}

.w3-modal-content {
    border-radius: 20px !important;
    padding: 20px !important;
    width: 500px !important;
}
</style>

<body>
    <!-- Preloader -->
    <div id="preloader"
        class="fixed inset-0 z-70 bg-default-50 transition-all visible opacity-100 h-screen w-screen flex items-center justify-center">
        <div class="animate-spin inline-block w-10 h-10 border-4 border-t-transparent border-primary rounded-full"
            role="status" aria-label="loading">
            <span class="sr-only">Loading...</span>
        </div>
    </div>



    <!-- Main Navigation Menu -->
    <header id="navbar" class="sticky top-0 z-20 border-b border-default-200 bg-transparent transition-all">
        <div class="lg:h-20 h-14 flex items-center">
            <div class="container">
                <div class="grid lg:grid-cols-3 grid-cols-2 items-center gap-4">
                    <div class="flex">
                        <!-- Mobile Menu Toggle Button -->
                        <button class="lg:hidden block " data-hs-overlay="#mobile-menu">
                            <i data-lucide="menu" class="w-7 h-7 text-default-600 me-4 hover:text-primary"></i>
                        </button>

                        <!-- Navbar Brand Logo -->
                        <a href="index.php">
                            <h2>MEALS 4 U</h2>
                            <!-- <img src="assets/logo-dark-6dbab3e1.png" alt="logo" class="h-10 flex dark:hidden"> -->
                            <!-- <img src="assets/logo-light-35c89c2c.png" alt="logo" class="h-10 hidden dark:flex"> -->
                        </a>
                    </div>

                    <!-- Nevigation Menu -->
                    <ul class="menu lg:flex items-center justify-center hidden relative" style="width: 627px;">
                        <!-- Home Menu -->
                        <li class="menu-item">
                            <a class="inline-flex items-center text-sm lg:text-base font-medium text-default-800 py-2 px-4 rounded-full hover:text-primary "
                                href="index.php">Home </a>
                        </li>

                        <li class="menu-item">
                            <a class="inline-flex items-center text-sm lg:text-base font-medium text-default-800 py-2 px-4 rounded-full hover:text-primary "
                                href="index.php#about">About Us </a>
                        </li>

                        <!-- <li class="menu-item">
                            <a class="inline-flex items-center text-sm lg:text-base font-medium text-default-800 py-2 px-4 rounded-full hover:text-primary "
                                href="menu.php">Menu </a>
                        </li> -->

                        <li class="menu-item">
                            <a class="inline-flex items-center text-sm lg:text-base font-medium text-default-800 py-2 px-4 rounded-full hover:text-primary "
                                href="food.php">Food</a>
                        </li>


                        <li class="menu-item">
                            <a class="inline-flex items-center text-sm lg:text-base font-medium text-default-800 py-2 px-4 rounded-full hover:text-primary "
                                href="meal.php">Meals </a>
                        </li>


                        
                    </ul>

                    <ul class="flex items-center justify-end gap-x-6">
                        <?php
                        if(isset($user_id)){
?>
 <a href="user/index.php"
                            class="py-5 px-10 font-medium text-white bg-primary rounded-full hover:bg-primary-500 transition-all main_btn">Dashboard</a>
<?php
                        }
                        else{
                            ?>
                            <a href="login.php"
                            class="py-5 px-10 font-medium text-white bg-primary rounded-full hover:bg-primary-500 transition-all main_btn">Sign
                            In</a>
                        <?php
                        }
                        ?>
                       
                    </ul>
                </div>
            </div>
        </div>
    </header>

    <!-- Mobile Menu (Sidebar Menu) -->
    <div id="mobile-menu"
        class="hs-overlay hs-overlay-open:translate-x-0 hidden -translate-x-full fixed top-0 left-0 transition-all transform h-full max-w-[270px] w-full z-60  border-r border-default-200 bg-white dark:bg-default-50"
        tabindex="-1">
        <div
            class="flex justify-center items-center border-b border-dashed border-default-200 h-16 transition-all duration-300">
            <a href="index.php">
                <h2>LOGO</h2>
                <!-- <img src="assets/logo-dark-6dbab3e1.png" alt="logo" class="h-10 flex dark:hidden">
                    <img src="assets/logo-light-35c89c2c.png" alt="logo" class="h-10 hidden dark:flex"> -->
            </a>
        </div>
        <div class="h-[calc(100%-4rem)]" data-simplebar>
            <nav class="hs-accordion-group p-4 w-full flex flex-col flex-wrap">
                <ul class="space-y-2.5">
                    <li>
                        <a class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm font-medium text-default-700 rounded-md hover:bg-default-100"
                            href="index.php">
                            Home
                        </a>
                    </li>

                    <li>
                        <a class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm font-medium text-default-700 rounded-md hover:bg-default-100"
                            href="#">
                            About us
                        </a>
                    </li>

                    <li>
                        <a class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm font-medium text-default-700 rounded-md hover:bg-default-100"
                            href="menu.php">
                            Menu
                        </a>
                    </li>

                    <li>
                        <a class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm font-medium text-default-700 rounded-md hover:bg-default-100"
                            href="#">
                            Testimoanils
                        </a>
                    </li>

                    <li>
                        <a class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm font-medium text-default-700 rounded-md hover:bg-default-100"
                            href="contact.php">
                            Contact Us
                        </a>
                    </li>


                </ul>
            </nav>
        </div>
    </div>

    <!-- Topbar Search Modal (Small Screen) -->
    <div id="mobileSearchSidebar"
        class="hs-overlay hidden w-full h-full fixed top-0 left-0 z-60 overflow-x-hidden overflow-y-auto">
        <div
            class="hs-overlay-open:mt-7 hs-overlay-open:opacity-100 hs-overlay-open:duration-500 mt-0 opacity-0 ease-out transition-all sm:max-w-lg sm:w-full m-3 sm:mx-auto">
            <div class="flex flex-col bg-white shadow-sm rounded-lg">
                <div class="relative flex w-full">
                    <span class="absolute start-4 top-3">
                        <i class="w-4 h-4 text-primary-500" data-lucide="search"></i>
                    </span>

                    <input
                        class="px-10 py-2.5 block w-full border-transparent placeholder-primary-500 rounded-lg text-sm bg-transparent text-primary-500"
                        placeholder="Search for items..." type="search">

                    <button class="absolute end-4 top-3" data-hs-overlay="#mobileSearchSidebar">
                        <i class="w-4 h-4 text-primary-500" data-lucide="x"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>